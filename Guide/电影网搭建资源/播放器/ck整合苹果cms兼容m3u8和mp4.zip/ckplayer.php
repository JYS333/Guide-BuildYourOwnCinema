<div id="a1" style="height:100%; overflow:hidden; margin:0px; padding:0px;"></div>
<script type="text/javascript" src="/ckplayer/ckplayer.js" charset="utf-8"></script>
<?php
if (strrpos($_SERVER["QUERY_STRING"], "m3u8") or strrpos($_SERVER["QUERY_STRING"], "M3U8")){ ?>

<script type="text/javascript">
    var flashvars={
   f:'/ckplayer/m3u8.swf',
   a:'<?php echo $_SERVER["QUERY_STRING"]; ?>',
   c:0,
   p:1,
   s:4,
   lv:0
    };
    var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
    var video=['<?php echo $_SERVER["QUERY_STRING"]; ?>->video/mp4'];
    CKobject.embed('/ckplayer/ckplayer.swf','a1','ckplayer_a1','100%','100%',false,flashvars,video,params);
</script>


<?php }else{ ?>

<script type="text/javascript">
    var flashvars={
        f:'<?php echo $_SERVER["QUERY_STRING"]; ?>',
        c:0,
        p:1
    };
    var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
    var video=['<?php echo $_SERVER["QUERY_STRING"]; ?>->video/mp4'];
    CKobject.embed('/ckplayer/ckplayer.swf','a1','ckplayer_a1','100%','100%',false,flashvars,video,params);
</script>


<?php } ?>
