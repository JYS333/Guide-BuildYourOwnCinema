String.prototype.replaceAll = function (s1, s2) {
  return this.replace(new RegExp(s1, "gm"), s2);
}
String.prototype.trim = function () {
  return this.replace(/(^\s*)|(\s*$)/g, "");
}
var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var base64DecodeChars = new Array(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);

function base64encode(str) {
  var out, i, len;
  var c1, c2, c3;
  len = str.length;
  i = 0;
  out = "";
  while (i < len) {
    c1 = str.charCodeAt(i++) & 0xff;
    if (i == len) {
      out += base64EncodeChars.charAt(c1 >> 2);
      out += base64EncodeChars.charAt((c1 & 0x3) << 4);
      out += "==";
      break
    }
    c2 = str.charCodeAt(i++);
    if (i == len) {
      out += base64EncodeChars.charAt(c1 >> 2);
      out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
      out += base64EncodeChars.charAt((c2 & 0xF) << 2);
      out += "=";
      break
    }
    c3 = str.charCodeAt(i++);
    out += base64EncodeChars.charAt(c1 >> 2);
    out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4));
    out += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6));
    out += base64EncodeChars.charAt(c3 & 0x3F)
  }
  return out
}

function base64decode(str) {
  var c1, c2, c3, c4;
  var i, len, out;
  len = str.length;
  i = 0;
  out = "";
  while (i < len) {
    do {
      c1 = base64DecodeChars[str.charCodeAt(i++) & 0xff]
    } while (i < len && c1 == -1);
    if (c1 == -1) break;
    do {
      c2 = base64DecodeChars[str.charCodeAt(i++) & 0xff]
    } while (i < len && c2 == -1);
    if (c2 == -1) break;
    out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));
    do {
      c3 = str.charCodeAt(i++) & 0xff;
      if (c3 == 61) return out;
      c3 = base64DecodeChars[c3]
    } while (i < len && c3 == -1);
    if (c3 == -1) break;
    out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));
    do {
      c4 = str.charCodeAt(i++) & 0xff;
      if (c4 == 61) return out;
      c4 = base64DecodeChars[c4]
    } while (i < len && c4 == -1);
    if (c4 == -1) break;
    out += String.fromCharCode(((c3 & 0x03) << 6) | c4)
  }
  return out
}

function utf16to8(str) {
  var out, i, len, c;
  out = "";
  len = str.length;
  for (i = 0; i < len; i++) {
    c = str.charCodeAt(i);
    if ((c >= 0x0001) && (c <= 0x007F)) {
      out += str.charAt(i)
    } else if (c > 0x07FF) {
      out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
      out += String.fromCharCode(0x80 | ((c >> 6) & 0x3F));
      out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F))
    } else {
      out += String.fromCharCode(0xC0 | ((c >> 6) & 0x1F));
      out += String.fromCharCode(0x80 | ((c >> 0) & 0x3F))
    }
  }
  return out
}

function utf8to16(str) {
  var out, i, len, c;
  var char2, char3;
  out = "";
  len = str.length;
  i = 0;
  while (i < len) {
    c = str.charCodeAt(i++);
    switch (c >> 4) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
        out += str.charAt(i - 1);
        break;
      case 12:
      case 13:
        char2 = str.charCodeAt(i++);
        out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
        break;
      case 14:
        char2 = str.charCodeAt(i++);
        char3 = str.charCodeAt(i++);
        out += String.fromCharCode(((c & 0x0F) << 12) | ((char2 & 0x3F) << 6) | ((char3 & 0x3F) << 0));
        break
    }
  }
  return out
}

var MAC = {
  'Url': document.URL,
  'Title': document.title,
  'UserAgent': function () {
    var ua = navigator.userAgent; //navigator.appVersion
    return {
      'mobile': !!ua.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
      'ios': !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
      'android': ua.indexOf('Android') > -1 || ua.indexOf('Linux') > -1, //android终端或者uc浏览器
      'iPhone': ua.indexOf('iPhone') > -1 || ua.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器
      'iPad': ua.indexOf('iPad') > -1, //是否iPad
      'trident': ua.indexOf('Trident') > -1, //IE内核
      'presto': ua.indexOf('Presto') > -1, //opera内核
      'webKit': ua.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
      'gecko': ua.indexOf('Gecko') > -1 && ua.indexOf('KHTML') == -1, //火狐内核
      'weixin': ua.indexOf('MicroMessenger') > -1 //是否微信 ua.match(/MicroMessenger/i) == "micromessenger",
    };
  }(),
  'Copy': function (s) {
    if (window.clipboardData) {
      window.clipboardData.setData("Text", s);
    } else {
      if ($("#mac_flash_copy").get(0) == undefined) {
        $('<div id="mac_flash_copy"></div>');
      } else {
        $('#mac_flash_copy').html('');
      }
      $('#mac_flash_copy').html('<embed src=' + SitePath + '"images/_clipboard.swf" FlashVars="clipboard=' + escape(s) + '" width="0" height="0" type="application/x-shockwave-flash"></embed>');
    }
    MAC.Pop.Msg(100, 20, '复制成功', 1000);
  },
  'Home': function (o, u) {
    try {
      o.style.behavior = 'url(#default#homepage)';
      o.setHomePage(u);
    } catch (e) {
      if (window.netscape) {
        try {
          netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
        } catch (e) {
          MAC.Pop.Msg(150, 40, '此操作被浏览器拒绝！请手动设置', 1000);
        }
        var moz = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
        moz.setCharPref('browser.startup.homepage', u);
      }
    }
  },
  'Fav': function (u, s) {
    try {
      window.external.addFavorite(u, s);
    } catch (e) {
      try {
        window.sidebar.addPanel(s, u, "");
      } catch (e) {
        MAC.Pop.Msg(150, 40, '加入收藏出错，请使用键盘Ctrl+D进行添加', 1000);
      }
    }
  },
  'Open': function (u, w, h) {
    window.open(u, 'macopen1', 'toolbars=0, scrollbars=0, location=0, statusbars=0,menubars=0,resizable=yes,width=' + w + ',height=' + h + '');
  },
  'Cookie': {
    'Set': function (name, value, days) {
      var exp = new Date();
      exp.setTime(exp.getTime() + days * 24 * 60 * 60 * 1000);
      var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
      document.cookie = name + "=" + escape(value) + ";path=/;expires=" + exp.toUTCString();
    },
    'Get': function (name) {
      var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
      if (arr != null) {
        return unescape(arr[2]);
        return null;
      }
    },
    'Del': function (name) {
      var exp = new Date();
      exp.setTime(exp.getTime() - 1);
      var cval = this.Get(name);
      if (cval != null) {
        document.cookie = name + "=" + escape(cval) + ";path=/;expires=" + exp.toUTCString();
      }
    }
  },
  'GoBack': function () {
    var ldghost = document.domain;
    if (document.referrer.indexOf(ldghost) > 0) {
      history.back();
    } else {
      window.location = "http://" + ldghost;
    }
  },
  'Adaptive': function () {
    if (maccms.mob_status == '1') {
      if (document.domain == maccms.url && MAC.UserAgent.mobile) {
        location.href = location.href.replace(maccms.url, maccms.wapurl);
      } else if (document.domain == maccms.wapurl && !MAC.UserAgent.mobile) {
        location.href = location.href.replace(maccms.wapurl, maccms.url);
      }
    }
  },
  'CheckBox': {
    'All': function (n) {
      $("input[name='" + n + "']").each(function () {
        this.checked = true;
      });
    },
    'Other': function (n) {
      $("input[name='" + n + "']").each(function () {
        this.checked = !this.checked;
      });
    },
    'Count': function (n) {
      var res = 0;
      $("input[name='" + n + "']").each(function () {
        if (this.checked) {
          res++;
        }
      });
      return res;
    }
  },
  'Qrcode': function () {
    $('.mac_qrcode').attr('src', 'http://api.maccms.com/qrcode/?w=150&h=150&url=' + MAC.Url);
  },
  'Image': {
    'Lazyload': {
      'Show': function () {
        $("img.lazy").lazyload();
        try {} catch (e) {};
      },
      'Box': function ($id) {
        $("img.lazy").lazyload({
          container: $("#" + $id)
        });
      }
    }
  },
  'Verify': {
    'Init': function () {
      MAC.Verify.Focus();
      MAC.Verify.Click();
    },
    'Focus': function () { //验证码框焦点
      $('body').on("focus", ".mac_verify", function () {
        $(this).removeClass('mac_verify').after(MAC.Verify.Show());
        $(this).unbind();
      });
    },
    'Click': function () { //点击刷新
      $('body').on('click', 'img.mac_verify_img', function () {
        $(this).attr('src', maccms.path + '/index.php/verify/index.html?');
      });
    },
    'Refresh': function () {
      $('.mac_verify_img').attr('src', maccms.path + '/index.php/verify/index.html?');
    },
    'Show': function () {
      return '<img class="mac_verify_img" src="' + maccms.path + '/index.php/verify/index.html?"  title="看不清楚? 换一张！">';
    }
  },
  'PageGo': {
    'Init': function () {
      $('.mac_page_go').click(function () {
        var that = $(this);
        var url = that.attr('data-url');
        var total = that.attr('data-total');
        var sp = that.attr('data-sp');
        var page = $('#page').val();

        if (page > 0 && (page <= total)) {
          url = url.replace(sp + 'PAGELINK', page).replace('PAGELINK', page);
          location.href = url;
        }
        return false;
      });
    }
  },
  'Hits': {
    'Init': function () {
      $.ajax({
        type: 'get',
        url: maccms.path + '/index.php/ajax/hits?mid=1&id=47142&type=update',
        timeout: 5000,
        dataType: 'json',
        error: function () {

        },
        success: function (json) {
          if (json.code == 1) {
            $(".mac_hits").each(function (i) {
              $type = $(".mac_hits").eq(i).attr('data-type');
              if ($type != 'insert') {
                $('.mac_hits_' + $type).html(eval('(json.data.' + $type + ')'));
              }
            });
          }
        }
      });

    }
  },
  'Score': {
    'Init': function () {
      if ($('.mac_score').length == 0) {
        return;
      }
      $('body').on('click', '.score_btn', function (e) {
        MAC.Score.Submit();
      });

      $.ajax({
        type: 'post',
        url: maccms.path + '/index.php/ajax/score?mid=' + $('.mac_score').attr('data-mid') + '&id=' + $('.mac_score').attr('data-id'),
        timeout: 5000,
        error: function () {
          $(".mac_score").html('评分加载失败');
        },
        success: function ($r) {
          MAC.Score.View($r);
        }
      });
    },
    'Submit': function () {
      var $s = $('.mac_score').find("input[name='score']").val();
      $.ajax({
        type: 'post',
        url: maccms.path + '/index.php/ajax/score?mid=' + $('.mac_score').attr('data-mid') + '&id=' + $('.mac_score').attr('data-id') + '&score=' + $s,
        timeout: 5000,
        error: function () {

        },
        success: function ($r) {
          MAC.Pop.Msg(100, 20, $r.msg, 1000);
          if ($r.code == 1) {
            MAC.Score.View($r);
          }
        }
      });
    },
    'View': function ($r) {
      $(".rating" + Math.floor($r.data.score)).attr('checked', true);
      $(".score_num").text($r.data.score_num);
      $(".score_all").text($r.data.score_all);
      $(".score_pjf").text($r.data.score);
    }
  },
  'Star': {
    'Init': function () {
      if ($('.mac_star').length == 0) {
        return;
      }
      $(".score-list a").hover(function () {
        $("#score-len").removeClass().addClass("s" + $(this).attr("val"));
        $(".score-alt").text($(this).attr("title"));
      }, function () {
        $("#score-len").removeClass().addClass(scoreClass);
        $(".score-alt").text(scoreAlt);
      });
      $(".score-list a").click(function () {
        $.ajax({
          type: 'get',
          url: maccms.path + '/index.php/ajax/score?mid=' + $('.mac_star').attr('data-mid') + '&id=' + $('.mac_star').attr('data-id') + '&score=' + ($(this).attr("score")),
          timeout: 5000,
          dataType: 'json',
          error: function () {
            MAC.Pop.Msg(100, 20, '网络异常！', 1000);
          },
          success: function (json) {
            if (json.code == 1) {
              MAC.Star.View(json);
              MAC.Pop.Msg(100, 20, '评分成功！', 1000);
            } else {
              MAC.Pop.Msg(100, 20, json.msg, 2000);
            }
          }
        });
      });
    },
    'View': function ($r) {
      scoreClass = "s" + Math.round($r.data.score / 2);
      scoreAlt = $("#star" + Math.round($r.data.score / 2)).attr("title");
      $("#score-len").removeClass().addClass(scoreClass);
      $(".score-alt").text(scoreAlt);
      $(".average-score").text($r.data.score);
      $(".average-score-box").animate({
        "left": $r.data.score * 10 + '%'
      });
      $(".schedule-score").animate({
        "width": $r.data.score * 10 + "%"
      });
    }
  },
  'Digg': {
    'Init': function () {
      $('body').on('click', '.digg_link', function (e) {
        var $that = $(this);
        if ($that.attr("data-id")) {
          $.ajax({
            url: maccms.path + '/index.php/ajax/digg.html?mid=' + $that.attr("data-mid") + '&id=' + $that.attr("data-id") + '&type=' + $that.attr("data-type"),
            cache: false,
            dataType: 'json',
            success: function ($r) {
              $that.addClass('disabled');
              if ($r.code == 1) {
                if ($that.attr("data-type") == 'up') {
                  $that.find('.digg_num').html($r.data.up);
                } else {
                  $that.find('.digg_num').html($r.data.down);
                }
              } else {
                $that.attr('title', $r.msg);
              }
            }
          });
        }
      });
    }
  },
  'Gbook': {
    'Login': 0,
    'Verify': 0,
    'Init': function () {
      $('body').on('keyup', '.gbook_content', function (e) {
        MAC.Remaining($(this), 200, '.gbook_remaining')
      });
      $('body').on('focus', '.gbook_content', function (e) {
        if (MAC.Gbook.Login == 1 && MAC.User.IsLogin != 1) {
          MAC.User.Login();
        }
      });
      $('body').on('click', '.gbook_submit', function (e) {
        MAC.Gbook.Submit();
      });
    },
    'Show': function ($page) {
      $.ajax({
        type: 'post',
        url: maccms.path + '/index.php/gbook/index?page=' + $page,
        timeout: 3000,
        error: function () {
          $(".mac_gbook_box").html('留言加载失败，请刷新...');
        },
        success: function ($html) {
          $(".mac_gbook_box").html($html);
        }
      });
    },
    'Submit': function () {
      if ($(".gbook_content").val() == '') {
        MAC.Pop.Msg(100, 20, '请输入您的留言!', 1000);
        return false;
      }
      $.ajax({
        type: 'post',
        url: maccms.path + '/index.php/gbook/saveData',
        data: $('.gbook_form').serialize(),
        success: function ($r) {
          MAC.Pop.Msg(100, 20, $r.msg, 1000);
          if ($r.code == 1) {
            location.reload();
          } else {
            if (MAC.Gbook.Verify == 1) {
              MAC.Verify.Refresh();
            }
          }
        }
      });
    }
  },
  'Search': {
    'Init': function () {
      $('.mac_search').click(function () {
        var that = $(this);
        var url = that.attr('data-href') ? that.attr('data-href') : maccms.path + '/index.php/vod/search.html';
        location.href = url + '?wd=' + encodeURIComponent($("#wd").val());
      });
    },
    'Submit': function () {

      return false;
    }
  },
  'Suggest': {
    'Init': function ($obj, $mid, $jumpurl) {
      $($obj).autocomplete(maccms.path + '/index.php/ajax/suggest?mid=' + $mid, {
        inputClass: "mac_input",
        resultsClass: "mac_results",
        loadingClass: "mac_loading",
        width: 281,
        scrollHeight: 300,
        cacheLength: 10,
        multiple: false,
        matchContains: true,
        autoFill: false,
        dataType: "json",
        parse: function ($r) {
          if ($r.code == 1) {
            var parsed = [];
            $.each($r['list'], function (index, row) {
              row.url = $r.url;
              parsed[index] = {
                data: row
              };
            });
            return parsed;
          } else {
            return {
              data: ''
            };
          }
        },
        formatItem: function (row, i, max) {
          return row.name;
        },
        formatResult: function (row, i, max) {
          return row.text;
        }
      }).result(function (event, data, formatted) {
        $($obj).val(data.name);
        location.href = maccms.path + '/index.php/vod/search/wd/' + encodeURIComponent(data.name) + '.html';
      });
    }
  },
  'History': {
    'BoxShow': 0,
    'Limit': 10,
    'Days': 7,
    'Json': '',
    'Display': true,
    'Init': function () {
      MAC.History.Create();
      $('.hd-bdv_record').hover(function (e) {
        $(this).find(".bdv-record-main").show();
      }, function () {
        $(this).find(".bdv-record-main").hide();
      });
    },
    'Clear': function () {
      MAC.Cookie.Del('mac_history');
      MAC.History.Create();
    },
    'Create': function ($id) {
      var jsondata = [];
      if (this.Json) {
        jsondata = this.Json;
      } else {
        var jsonstr = MAC.Cookie.Get('mac_history');
        if (jsonstr != undefined) {
          jsondata = eval(jsonstr);
        }
      }
      html = '';
      if (jsondata.length > 0) {
        if (jsondata.length > 10) {
          var history_num = 10;
        } else {
          history_num = jsondata.length;
        }
        html += '<div class="bdv-record-content"><div class="bdv-record-bd"><ul>';
        for ($i = 0; $i < history_num; $i++) {
          html += '<li class="comic"> <a href="' + jsondata[$i].link + '" target="_blank" class="bdv-record-item-ttl">' + jsondata[$i].name + '</a> <span class="bdv-record-update"></span> <span class="bdv-record-type">' + jsondata[$i].typename + '</span> </li>';
        }
        html += '</ul></div>';
        html += '<div class="bdv-record-ft"> <a href="javascript:void(0)" onclick="MAC.History.Clear();" class="bdv-record-control">清空记录</a> </div>';
        html += '</div>';
      } else {
        html += '<div class="bdv-record-content bdv-record-noresult"><div class="bdv-record-bd"><p>您最近没有观看过剧集节目。</p></div><div class="bdv-record-ft"> &nbsp; </div></div>';
      }
      $('.bdv-record-main').html(html);
    },
    'Insert': function (id, name, link, typename) {
      var jsondata = MAC.Cookie.Get('mac_history');
      if (jsondata != undefined) {
        this.Json = eval(jsondata);
        for ($i = 0; $i < this.Json.length; $i++) {
          if (this.Json[$i].link == link) {
            return false;
          }
        }
        if (!link) {
          link = document.URL;
        }
        jsonstr = '{video:[{"id":"' + id + '","name":"' + name + '","link":"' + link + '","typename":"' + typename + '"},';
        for ($i = 0; $i < this.Limit; $i++) {
          if (this.Json[$i]) {
            if (this.Json[$i].id != id) {
              jsonstr += '{"id":"' + this.Json[$i].id + '","name":"' + this.Json[$i].name + '","link":"' + this.Json[$i].link + '","typename":"' + this.Json[$i].typename + '"},';
            } else {
              continue;
            }
          } else {
            break;
          }
        }
        jsonstr = jsonstr.substring(0, jsonstr.lastIndexOf(','));
        jsonstr += "]}";
      } else {
        jsonstr = '{video:[{"id":"' + id + '","name":"' + name + '","link":"' + link + '","typename":"' + typename + '"}]}';
      }
      this.Json = eval(jsonstr);
      MAC.Cookie.Set('mac_history', jsonstr, this.Days);
    }
  },

  'Ulog': {
    'Init': function () {
      MAC.Ulog.Set();
      MAC.Ulog.Click();
    },
    'Get': function () {

    },
    'Set': function () {
      if ($(".mac_ulog_set").attr('data-mid')) {
        var $that = $(".mac_ulog_set");
        $.get(maccms.path + '/index.php/user/ajax_ulog/?mid=' + $that.attr("data-mid") + '&id=' + $that.attr("data-id") + '&sid=' + $that.attr("data-sid") + '&nid=' + $that.attr("data-nid") + '&type=' + $that.attr("data-type"));
      }
    },
    'Click': function () {
      $('body').on('click', 'a.mac_ulog', function (e) {
        //是否需要验证登录
        if (MAC.User.IsLogin == 0) {
          MAC.User.Login();
          return;
        }

        var $that = $(this);
        if ($that.attr("data-id")) {
          $.ajax({
            url: maccms.path + '/index.php/user/ajax_ulog/?mid=' + $that.attr("data-mid") + '&id=' + $that.attr("data-id") + '&type=' + $that.attr("data-type"),
            cache: false,
            dataType: 'json',
            success: function (json) {
              MAC.Pop.Msg(100, 20, json.msg, 1000);
              if (json.code == 1) {
                $that.addClass('disabled');
              } else {
                $that.attr('title', json.msg);
              }
            }
          });
        }
      });
    }
  },
  'User': {
    'BoxShow': 0,
    'IsLogin': 0,
    'UserName': '',
    'GroupName': '',
    'Init': function () {
      if ($('.mac_user').length == 0) {
        return;
      }

      $('.mac_user').hover(function (e) {
        $('.mac_user_box').show();
      }, function () {
        $('.mac_user_box').hover(function () {
          MAC.User.BoxShow = 1;
        }, function () {
          MAC.User.BoxShow = 0;
          $('.mac_user_box').hide();
        });
      });

      if (MAC.Cookie.Get('user_id') != undefined && MAC.Cookie.Get('user_id') != '') {
        var url = maccms.path + '/index.php/user';
        MAC.User.UserName = MAC.Cookie.Get('user_name');
        MAC.User.GroupName = MAC.Cookie.Get('group_name');
        MAC.User.IsLogin = 1;

        if ($('.mac_user').prop("outerHTML").substr(0, 2) == '<a') {
          $('.mac_user').attr('href', url);
          $('.mac_user').text(MAC.User.UserName);
        } else {
          //$('.mac_user').html('<a class="mac_text" href="'+ url +'">'+ name +'</a>');
        }

        var html = '<div class="mac_drop_box mac_user_box" style="display: none;">';
        html += '<ul class="logged"><li><a target="_blank" href="' + url + '">用户中心</a></li><li class="logout"><a class="logoutbt" href="javascript:;" onclick="MAC.User.Logout();" target="_self"><i class="user-logout"></i>退出</a></li></ul>'

        $('.mac_user').after(html);
        var h = $('.mac_user').height();
        var position = $('.mac_user').position();
        $('.mac_user_box').css({
          'left': position.left,
          'top': (position.top + h)
        });

      } else {
        $('body').on('click', '.mac_user', function (e) {
          MAC.User.Login();
        });
      }
    },
    'CheckLogin': function () {
      if (MAC.User.IsLogin == 0) {
        MAC.User.Login();
      }
    },
    'Login': function () {
      var ac = 'ajax_login';
      if (MAC.Cookie.Get('user_id') != undefined && MAC.Cookie.Get('user_id') != '') {
        ac = 'ajax_info';
      }
      MAC.Pop.Show(400, 380, '用户登录', maccms.path + '/index.php/user/' + ac, function ($r) {
        $('body').on('click', '.login_form_submit', function (e) {
          $.ajax({
            type: 'post',
            url: maccms.path + '/index.php/user/login',
            data: $('.mac_login_form').serialize(),
            success: function ($r) {
              alert($r.msg);
              if ($r.code == 1) {
                location.reload();
              }
            }
          });
        });
      });
    },
    'Logout': function () {
      $.ajax({
        type: 'post',
        url: maccms.path + '/index.php/user/logout',
        success: function ($r) {
          MAC.Pop.Msg(100, 20, $r.msg, 1000);
          if ($r.code == 1) {
            location.reload();
          }
        }
      });
    }
  },
  'Pop': {
    'Remove': function () {
      $('.mac_pop_bg').remove();
      $('.mac_pop').remove();
    },
    'Msg': function ($w, $h, $msg, $timeout) {
      if ($('.mac_pop_bg').length != 1) {
        MAC.Pop.Remove();
      }
      $('body').append('<div class="mac_pop_bg"></div><div class="mac_pop"><div class="pop-msg"></div></div>');
      $('.mac_pop .pop_close').click(function () {
        $('.mac_pop_bg,.mac_pop').remove();
      });

      $('.mac_pop').width($w);
      $('.mac_pop').height($h);
      $('.pop-msg').html($msg);
      $('.mac_pop_bg,.mac_pop').show();
      setTimeout(MAC.Pop.Remove, $timeout);
    },
    'Show': function ($w, $h, $title, $url, $callback) {
      if ($('.mac_pop_bg').length != 1) {
        MAC.Pop.Remove();
      }

      $('body').append('<div class="mac_pop_bg"></div><div class="mac_pop"><div class="pop_top"><h2></h2><span class="pop_close">Ｘ</span></div><div class="pop_content"></div></div>');
      $('.mac_pop .pop_close').click(function () {
        $('.mac_pop_bg,.mac_pop').remove();
      });

      $('.mac_pop').width($w);
      $('.mac_pop').height($h);
      $('.pop_content').html('');
      $('.pop_top').find('h2').html($title);

      $.ajax({
        type: 'post',
        url: $url,
        timeout: 3000,
        error: function () {
          $(".pop_content").html('加载失败，请刷新...');
        },
        success: function ($r) {
          $(".pop_content").html($r);
          $callback($r);
        }
      });

      $('.mac_pop_bg,.mac_pop').show();
    }
  },
  'AdsWrap': function (w, h, n) {
    document.writeln('<img width="' + w + '" height="' + h + '" alt="' + n + '" style="background-color: #CCCCCC" />');
  },
  'Css': function ($url) {
    $("<link>").attr({
      rel: "stylesheet",
      type: "text/css",
      href: $url
    }).appendTo("head");
  },
  'Js': function ($url) {
    $.getScript($url, function (response, status) {

    });
  },
  'Desktop': function (s) {
    location.href = maccms.path + '/index.php/ajax/desktop?name=' + encodeURI(s) + '&url=' + encodeURI(location.href);
  },
  'Timming': function () {
    var t = (new Image());
    t.src = SitePath + 'inc/timming.php?t=' + Math.random();
  },
  'Error': function (tab, id, name) {
    MAC.Open(SitePath + "inc/err.html?tab=" + tab + "&id=" + id + "&name=" + encodeURI(name), 400, 220);
  },
  'AddEm': function (obj, i) {
    var oldtext = $(obj).val();
    $(obj).val(oldtext + '[em:' + i + ']');
  },
  'Remaining': function (obj, len, show) {
    var count = len - $(obj).val().length;
    if (count < 0) {
      count = 0;
      $(obj).val($(obj).val().substr(0, 200));
    }
    $(show).text(count);
  },
  'Comment': {
    'Login': 0,
    'Verify': 0,
    'Init': function () {
      $('body').on('click', '.comment_face_box img', function (e) {
        var obj = $(this).parents(".comment_form").find('.comment_content');
        MAC.AddEm(obj, $(this).attr('data-id'));
      });
      $('body').on('keyup', '.comment_content', function (e) {
        var obj = $(this).parents(".comment_form").find('.comment_remaining');
        MAC.Remaining($(this), 200, obj)
      });
      $('body').on('focus', '.comment_content', function (e) {
        if (MAC.Comment.Login == 1 && MAC.User.IsLogin != 1) {
          //MAC.User.Login();
        }
      });

      $('body').on('click', '.comment_report', function (e) {
        var $that = $(this);
        if ($(this).attr("data-id")) {
          $.ajax({
            url: maccms.path + '/index.php/comment/report.html?id=' + $that.attr("data-id"),
            cache: false,
            dataType: 'json',
            success: function ($r) {
              $that.addClass('disabled');
              MAC.Pop.Msg(120, 20, $r.msg, 1000);
              if ($r.code == 1) {}
            }
          });
        }
      });

      $('body').on('click', '.comment_reply', function (e) {
        var $that = $(this);
        if ($that.attr("data-id")) {
          var str = $that.html();
          $('.comment_reply_form').remove();
          if (str == '取消回复') {
            $that.text('回复');
            return false;
          }
          if (str == '回复') {
            $('.comment_reply').text('回复');
          }
          var html = $('.comment_form').prop("outerHTML");
          var oo = $(html);
          oo.addClass('comment_reply_form');
          oo.find('input[name="comment_pid"]').val($that.attr("data-id"));
          $that.parent().after(oo);
          $that.text('取消回复');
        }
      });

      $('body').on('click', '.comment_submit', function (e) {
        var $that = $(this);
        MAC.Comment.Submit($that);
      });
    },
    'Show': function ($page) {
      if ($(".mac_comment").length > 0) {
        $.ajax({
          type: 'get',
          url: maccms.path + '/index.php/comment/ajax.html?rid=' + $('.mac_comment').attr('data-id') + '&mid=' + $('.mac_comment').attr('data-mid') + '&page=' + $page,
          timeout: 5000,
          error: function () {
            $(".mac_comment").html('评论加载失败，请刷新...');
          },
          success: function ($r) {
            $(".mac_comment").html($r);
          }
        });
      }
    },
    'Reply': function ($o) {

    },
    'Submit': function ($o) {
      var form = $o.parents('form');
      if ($(form).find(".comment_content").val() == '') {
        MAC.Pop.Msg(120, 20, '请输入您的评论！', 1000);
        return false;
      }
      if ($('.mac_comment').attr('data-mid') == '') {
        MAC.Pop.Msg(100, 20, '模块mid错误！', 1000);
        return false;
      }
      if ($('.mac_comment').attr('data-id') == '') {
        MAC.Pop.Msg(100, 20, '关联id错误！', 1000);
        return false;
      }

      $.ajax({
        type: 'post',
        url: maccms.path + '/index.php/comment/saveData',
        data: $(form).serialize() + '&comment_mid=' + $('.mac_comment').attr('data-mid') + '&comment_rid=' + $('.mac_comment').attr('data-id'),
        success: function ($r) {
          MAC.Pop.Msg(120, 20, $r.msg, 1000);
          if ($r.code == 1) {
            MAC.Comment.Show(1);
          } else {
            if (MAC.Comment.Verify == 1) {
              MAC.Verify.Refresh();
            }
          }
        }
      });
    }
  }
}

$(function () {
  //异步加载图片初始化
  //MAC.Image.Lazyload.Show();
  //历史记录初始化
  //MAC.History.List('history');
  //用户登录初始化
  //MAC.Login.Init('login');
  //搜索联想初始化
  //MAC.Suggest.Show('wd',10, SitePath+'inc/ajax.php?ac=suggest&aid='+SiteAid, SitePath+'index.php?m=vod-search-wd-');
  //顶踩初始化
  //MAC.Digg.Show(SitePath+'inc/ajax.php?ac=digg&aid='+SiteAid+'&id='+SiteId);
  //ajax评论初始化
  //MAC.Comment.Show(SitePath+'index.php?m=comment-show-aid-'+SiteAid+'-vid-'+SiteId);
  //定时任务初始化
  //MAC.Timming();
  MAC.Adaptive();
  MAC.Verify.Init();
  MAC.PageGo.Init();
  MAC.User.Init();
  MAC.History.Init();
  MAC.Digg.Init();
  MAC.Score.Init();
  MAC.Star.Init();
  MAC.Ulog.Init();
  MAC.Suggest.Init('.mac_wd', 1, '');
  $(".top-piclist li").hover(function () {
    $(this).addClass("active").siblings().removeClass("active");
  }, function () {});
  $(".video-rank li").hover(function () {
    $(this).addClass("li-video-hover").siblings().removeClass("li-video-hover");
  }, function () {});
  $(".bt-top").click(function () {
    $(document).scrollTop(0);
  });
  if ($(document).scrollTop() > 150) {
    $(".bt-top").show();
  } else {
    $(".bt-top").hide();
  }
  if (($(".top_left").length != 0) && ($(document).scrollTop() >= $(".top_right").offset().top)) {
    $(".top_left").addClass("fixed");
  }
  $(window).scroll(function () {
    if ($(document).scrollTop() > 150) {
      $(".bt-top").show();
    } else {
      $(".bt-top").hide();
    }
    if ($(".top_left").length != 0) {
      if ($(document).scrollTop() >= $(".top_right").offset().top) {
        $(".top_left").addClass("fixed");
      } else {
        $(".top_left").removeClass("fixed");
      }
    }
  });
  $(".share-wrap").hover(function () {
    $(this).find(".bdsharebuttonbox").show();
  }, function () {
    $(this).find(".bdsharebuttonbox").hide();
  });
  $("#siteslist").hover(function () {
    $(this).find("#playSiteMore").show();
  }, function () {
    $(this).find("#playSiteMore").hide();
  });
  $(".play-sites-more a").click(function () {
    $(this).hide().siblings().show();
    $("#player-show-" + $(this).attr("sid")).show().siblings("a").hide();
    $("#playSiteMore").hide();
    $("#playlist-" + $(this).attr("from") + "-" + $(this).attr("sid")).show().siblings().hide();
  });
  $(".playname li").click(function () {
    if (!$(this).hasClass("on")) {
      $(this).addClass("on").siblings().removeClass("on");
      $("#playlist-" + $(this).attr("from") + "-" + $(this).attr("sid")).show().siblings().hide();
    }
  });
  $(".switch-tab").hover(function () {
    if (!$(this).hasClass("active")) {
      $(this).addClass("active").siblings().removeClass("active");
      $("#" + $(this).attr("switch")).show().siblings().hide();
    }
  });
  $(".switch-toggle").hover(function () {
    $("#" + $(this).attr("switch")).show();
  }, function () {
    $("#" + $(this).attr("switch")).hide();
  });
  $(".li-serie-fold").click(function () {
    $(this).parent().toggle().siblings().toggle();
  });
  $(".toggle-intro").click(function () {
    $(this).parent().toggle().siblings(".p-intro-bref").toggle();
  });
  $(".more-toggle").click(function () {
    $(this).parent().toggle().siblings("div").toggle();
  });
  $('body').on('click', '#cmt-input-tip', function (e) {
    $(this).hide().siblings("form").find(".ui-form").show();
  });
  $('body').on('click', '.emotion', function (e) {
    $(this).parents(".ui-form").siblings(".smileBoxOuter").toggle();
  });
  $(document).on("click", function (e) {
    if ($(e.target).closest(".emotion,#smileBoxOuter").length == 0) {
      $(".smileBoxOuter").hide();
    }
  });
});
