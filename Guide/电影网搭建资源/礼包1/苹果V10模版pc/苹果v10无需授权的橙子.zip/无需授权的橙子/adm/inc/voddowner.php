<?php
return array (
	'xunlei' => array (
		'status'	=> '1',
		'from'	=> 'xunlei',
		'show'	=> '迅雷下载',
		'des'	=> '迅雷下载',
		'ps'	=> '0',
		'parse'	=> '',
		'sort'	=> '4',
		'tip'	=> '需下载迅雷客户端',
	),
	'bt' =>	array (
		'status'=> '1',
		'from'	=> 'bt',
		'show'	=> 'BT下载',
		'des'	=> 'BT下载',
		'ps'	=> '0',
		'parse'	=> '',
		'sort'	=> '3',
		'tip'	=> '需下载迅雷客户端',
	),
	'ftp' => array (
		'status'=> '1',
		'from'	=> 'ftp',
		'show'	=> 'FTP下载',
		'des'	=> 'FTP下载',
		'ps'	=> '0',
		'parse'	=> '',
		'sort'	=> '2',
		'tip'	=> '需下载迅雷客户端',
	),
	'http' => array (
		'status'=> '1',
		'from'	=> 'http',
		'show'	=> 'HTTP下载',
		'des'	=> 'HTTP下载',
		'ps'	=> '0',
		'parse'	=> '',
		'sort'	=> '1',
		'tip'	=> '在线下载',
	)
);
?>