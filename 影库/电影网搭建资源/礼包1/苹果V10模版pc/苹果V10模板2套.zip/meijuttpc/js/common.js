$(function(){
	$("#keyword").autocomplete('/inc/ajax.asp?action=search&order=hit', {
		minChars: 1,
		scrollHeight:196,
		width:382,
		selectFirst:false,
		parse:function(data){
			return $.map(eval(data), function (row) {
				return {
					data: row
				}
			});
		},
		formatItem:function(row, i, max) {
			return '<p><em>'+i+'</em><a href="'+row.link+'" target="_blank" class="content-link">'+unescape(row.name)+'</a></p><span>'+row.time+'</span>';
		}
	})
	$('#roll').hide();
	$(window).scroll(function () {
		if ($(window).scrollTop() >= 600) {
			$('#roll').fadeIn(600);
		} else {
			$('#roll').fadeOut(100);
		}
	});
	$('#rollTop').click(function () {
		$('html,body').animate({
			scrollTop: '0px'
		}, 1200);
	});
	$('#rollBottom').click(function () {
		$('html,body').animate({
			scrollTop: $('#footer').offset().top
		}, 1200);
	});
	$("#favmy").click(function () {
		AddMy();
	});
	if ($("#hot_info").length > 0) {
		$("#hot_info").load($("#hot_info").attr('href'));
	}
	//
	if ($("#hot_video").length > 0) {
		$("#hot_video").load($("#hot_video").attr('href'));
	}
	if ($(".more-text").length > 0) {
		$(".more-text").each(function(i) {
			if($(this).prev().outerWidth()<240){$(this).hide()}else{$(this).prev().addClass("hide-text")}
        });
		$(".more-text").click(function(){
			$(this).parent().toggleClass("no-more");
			$(this).toggleClass("more-text-2");
		});
	}
	if($(".week-tabs").length>0){
		var dt=new Date(),week=dt.getDay(),timeStr=dt.getTime(),itemDay,str='';
		week=week==0?6:week-1;
		$(".week-tabs label").eq(week).addClass("current");
		$(".tabs-list").eq(week).addClass("current-tab");
	}
	if($(".tabs").length>0){
		$(".tabs label").click(function(){
			$(this).addClass("current").siblings().removeClass("current");
			$(".tabs-list").hide().eq($(".tabs label").index($(this))).fadeIn();
		});
		$(".tabs label").each(function(i) {
           $(this).append("<em>["+$(".tabs-list").eq(i).find("li:last").attr("data-title")+"]</em>")
        });
	}
	//showsearch();
});
