'use strict';var _typeof='function'==typeof Symbol&&'symbol'==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&'function'==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?'symbol':typeof e},_ref2,_ref3,_ref4,_ref5,_ref6,_ref7,_ref8,_ref9,_ref10,_fed;

function _defineProperty(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}

var _a='\u53F2\u8FD8\u53E3\u4E0B\u6781?Q\u8981\u8BB0\u3010\u7AD9,\u8BEF\u5230\u8BBF\u652F\u4E0D\u5165\u6D4F\u8FD4\u67E5\u79F0\u8BC4\u679C7\u4F5C\u5668\u8D34\u5B57\u81F3\u89C8qf\u4F60\u64CD&\u5207|\u65E0L<w\'-\u95EE\u4EE5\u53CA\u83B7\u63D0)=\u6301P2@\u6210W\u540D\u8BA4\uFF1A\uFF1F\u4E0A\u95E8\u6062\u8F93\u5982\u4E00j\u7801\u4F9B3v\u4EAB\u7A7A\u5F55\u770Bl\u5386(\u8BF7\u8D39\u6362pg\u5F0F\u624B\u7ED1\u59278\u7528\u9875\u8F7D\u9898\u62E9\u4F7F\u901F\u82B1\u5FAE\u82F9\u6570\u63A5y\u6B64\u9A8C\\\u7CFB4\u9664\u91CD\u5145\uFF0C[\u52A0h\u7EA7\u8005\u70ED\u8D2DUS\u636E\u5236V\u7D22\u9519{1\u51FA\u6216O\u503C;o\u8BC1 !ku\u5237\u8BD5\u5B9A\u85CF+\u3011\u786E\u6682\u52A8\u5220\u5185H\uFF01\u53EFM\u673A\u77EDCE.tBd\u6743\u591A\u6536n\u7ED9\u6A59\u4E3Be"c\u590D\u8BE5\u7EBF\u4E2A\u65B0>\u529F\u5C11\u5DF2sR\u7684\u5728\u54179F\u94FEIT\u6D88\u7531AJ\u9009\u7C98\u97625_$\u8D25\u8054\u4ECB\u641C\u53D6\u79EF]\u5347i\u4EE3m\u68386%\u66F4b\u8BBAr\u5931a\n\u4FE1z\u7ECD\u5B500\u597D\u535A\u9700^*/DN\u6E05\u89C2\u89E3\u672C\u5361\u5206}x\u6A21\u53CB\u4E70:#\u56DE',
_b='\u67E5\u8BB0\u8BBA\u79EF<\u9009\u65B0\u5C11\u5206N\u5B57s\u6A21fLc%\u7C98>\u5F55\u82B1\u652Fe\u3010\u66F4r!\u7684I\u7531\u6682\u64CD\u7ED9R\u85CF\u81F3\u8BC1t\u5728\u63D0\u89C2*\u53EF\u6301\u4FE1\u89E34)\u8FD4\u9664\u8D2DD\u8BBF\u5145\u5347\u5386\u9700j\u62E9\u624Bu2z\u7ECD\u679C\uFF1A3\u6062n\u8BEF\u6362\u4E0D\u6210\u51FAOB\u79F08\u9519[\u636E\u95E8\u4EE5\u7EA7gC\uFF01&U\u8D39\u786E\u6570\u5B50\u7801/\u53F2\u9A8C\u8BA4\u6A59\u8F93}E\u4EE3\u8005\u6216\u91CD6\u7528\u7EBF\u5931\u8BD5m\u5927M\u53E3\u4E70\u77ED@\u5668\u4F60\u5165SW\u6781\u673A\u8981#\u5230\u4E00\n\u529FF\u82F9;^\'\u770B\u5361V\u6E05(d\u9875\\k{h\u4F7Fql\u52A0yo\u8BE5\u7CFB\u53D6=v\u5220\u70ED]\u4ECB\u53CB\u94FE\u7AD9\u8FD8$"\u641C\u4EAB\u83B7\u6743\u597D\u6536\u4F9B0_:\u901F\u8F7D\u5207\u4E0B+\u6D88\u53CA\u6B64\u672C\uFF0C\u4E3B\u591A\u8BC4\u54171\u540D\u5236\u89C8,5.\u5F0F|x\u52A8 \uFF1F\u95EE\u65E0\u5185\u5982\u4F5C\u8BF7w\u590D\u6D4FA\u9898JT\u63A5aH\u7ED1b\u503C\u4E0AP\u5FAE\u8D25\u5B9A\u535A\u9762\u6838i7\u7D22\u8054\u56DE\u30119-\u5DF2\u4E2ApQ\u7A7A\u5237?\u8D34',
_c='c$pn\u5B57\u6A59\u6743d>ML\u4E2AB\u52A0\uFF1Fa\u5361\u65E0\u8D25\u5185\u7528\u6062-\u7531\u6838\u8BBF\u8BC4\u53CB(\u81F3\u5F55\u4F60\u8BA4z\u6301\u5C11\u53CA\u8BD5\u5386!\u6570\u77EDi\u535A\u70ED\u5668VA\u5230j\u7ED9\u6E05m\u65B0\u79F0\u8D2D#\u6781\u7EBF\u8FD4\u8BE5\u6210b\u53E3\u673A\u89E3\u6A21\u85CF\u4EE5\u4EAB_\u4E00J\u8FD8\u590D,\u3011\u5220\u8BEF4\u5728\u8F7D\u5417\u6216\u62E93\u8981^\u52A8\u6536\uFF1A+\u6D4F\u95E8\u53D6\u7CFB\u9762\u5FAEO:"tP\u5237*\u4F7F\u5DF2\uFF01N\u5165\u63D0\u5927%8\u6B64\u5982\u8BC1\u641C\uFF0C&\u4E70\u7C98<R\u652F.T1\u91CD\u7EA7\u8BB0\u5145\u52070\\@kh\u8D39\u67E5\u770B\u636E\u5B50{su\u4F9B\u4E0AqI\u4E0B?\u63A5\u8BF7\u679C\'g\u7801\u53F2\u4EE3v\u95EE\u9664\u94FE\u901F\u9875\u8054\u8D34\u7ED1\u5347\u89C2=\u97005l[\no\u5931]\u5F0F\u597D\u56DE\u82F9\u51FA\u53EF\u64CD\u79EFS/\u4E0DQ\u786E\u95192\u529Fw\u8005e \u9009U\u4E3BH\u3010\u7684\u591A)7\u7D226y\u540D\u8F93;\u82B1f\u8BBA\u4FE1\u6682r\u6362\u7A7A\u83B7\u9898\u4F5C\u66F4\u9A8C\u89C8\u7ECDC\u4ECB\u624BW9\u5206FD}x\u672C\u5B9A\u6D88|\u7AD9\u503C\u5236E';


window['reload'] = function(e){};

var fed = (_fed = {}, _defineProperty(_fed, 'global', (_ref2 = {}, _defineProperty(_ref2, 'lazy', function(e) {
	$(e)['lazyload'](_defineProperty({}, 'effect', 'fadeIn'))
}), _defineProperty(_ref2, 'swip', function(e) {
	var t, f = new Swiper(e, (t = {}, _defineProperty(t, 'wrapperClass', 'fed-swip-wrapper'), _defineProperty(t, 'slideClass', 'fed-swip-slide'), _defineProperty(t, 'pagination', '.fed-swip-pagin'), _defineProperty(t, 'bulletClass', 'fed-swip-bullet'), _defineProperty(t, 'bulletActiveClass', 'fed-swip-this'), _defineProperty(t, 'nextButton', '.fed-swip-next'), _defineProperty(t, 'prevButton', '.fed-swip-prev'), _defineProperty(t, 'paginationClickable', !0), _defineProperty(t, 'lazyLoading', !0), _defineProperty(t, 'lazyLoadingClass', 'fed-swip-lazy'), _defineProperty(t, 'lazyLoadingInPrevNext', !0), _defineProperty(t, 'autoplay', 5e3), _defineProperty(t, 'loop', !0), t))
}), _defineProperty(_ref2, 'copy', function() {
	var f = '';
	0 < $('.fed-foot-info .fed-contains')['length'] ? $('.fed-foot-info .fed-contains')['append'](f) : fed['player']['verify']()
}), _defineProperty(_ref2, 'login', function(e) {
	$(e)['click'](function() {
		fed['user']['login']()
	})
}), _defineProperty(_ref2, 'focus', function(e, t) {
	$(document)['on']('focus', t, function() {
		$(this)['attr']('type') != 'radio' && $(this)['attr']('type') != 'submit' && $(e)['hide']()
	}), $(document)['on']('blur', t, function() {
		$(e)['fadeIn'](500)
	})
}), _defineProperty(_ref2, 'gotop', function(e) {
	$(e)['click'](function() {
		$('html,body')['animate'](_defineProperty({}, 'scrollTop', 0), 200)
	})
}), _defineProperty(_ref2, 'submit', function(e, t) {
	$(document)['on']('keyup', t, function(f) {
		var s = window['event'] ? f['keyCode'] : f['which'];
		13 == s && $(e)['click']()
	})
}), _defineProperty(_ref2, 'version', 'vfed 3.0(苹果CMSv10)'), _defineProperty(_ref2, 'jumpurl', 'http://vfed.cc'), _defineProperty(_ref2, 'addmask', function(e) {
	$('.fed-mask')['remove'](), $(e)['append']('<div class="fed-mask fed-bgc-ashen fed-hide-sm fed-show"></div>'), $('.fed-play-iframe')['addClass']('fed-left')
}), _defineProperty(_ref2, 'delmask', function(e) {
	$(e)['remove'](), $('.fed-play-iframe')['removeClass']('fed-left')
}), _defineProperty(_ref2, 'click', function(e) {
	$(document)['click'](function() {
		$('.fed-play-box')['removeClass']('fed-show'), $('.fed-nav-input, .fed-gbook-content')['removeClass']('fed-bdr-gules'), $('.fed-pop-btn')['removeClass']('fed-pop-top'), $('.fed-pop-channel')['removeClass']('fed-show'), $('.fed-pop-navbar ul li')['removeClass']('fed-cells-top fed-cells-right'), fed['global']['delmask']('.fed-mask,.fed-mode-info'), $('.fed-conceal')['hide'](), fed['navbar']['close'](), fed['navbar']['edge'](), $('.fed-colo-info')['animate'](_defineProperty({}, 'width', 'hide'), 100)
	}), $(document)['on']('click', e, function(n) {
		n['stopPropagation']()
	})
}), _defineProperty(_ref2, 'ajax', function(e) {
	$['get'](e)
}), _defineProperty(_ref2, 'tips', function(e) {
	alert(e)
}), _defineProperty(_ref2, 'width', function() {
	return window['innerWidth'] ? window['innerWidth'] : document['documentElement']['offsetWidth'] == document['documentElement']['clientWidth'] ? document['documentElement']['offsetWidth'] : document['documentElement']['clientWidth'] + getScrollWidth()
}), _defineProperty(_ref2, 'height', function() {
	return window['innerHeight'] ? window['innerHeight'] : document['documentElement']['offsetHeight'] == document['documentElement']['clientHeight'] ? document['documentElement']['offsetHeight'] : document['documentElement']['clientHeight'] + getScrollHeight()
}), _defineProperty(_ref2, 'errors', function(e, t, r, u) {
	fed['comment']['count'](), $(document)['on']('click', e, function() {
		$['post'](vfed['tpl'] + ('asset/fed/create.php?id=err'), $(u)['serialize'](), function(d) {
			$(e)['text'](d['msg'])['addClass']('fed-btn-disad')['removeClass'](r)
		}, 'json')
	})
}), _defineProperty(_ref2, 'qrcode', function() {
	var e;
	$('.fed-side-code')['qrcode']((e = {}, _defineProperty(e, 'render', 'canvas'), _defineProperty(e, 'ecLevel', 'Q'), _defineProperty(e, 'minVersion', 3), _defineProperty(e, 'background', '#fff'), _defineProperty(e, 'fill', '#333'), _defineProperty(e, 'quiet', 3), _defineProperty(e, 'mode', 4), _defineProperty(e, 'mSize', 0.2), _defineProperty(e, 'text', window['href']), _defineProperty(e, 'image', $('.fed-side-image')[0]), e))
}), _defineProperty(_ref2, 'share', function(e) {
	$['post'](vfed['tpl'] + ('asset/fed/create.php?id=sha'), 'url=' + window['href'], function(f) {
		$(e)['click'](function() {
			if ($('body')['append']('<div id="fed-link-share" style="position: absolute;left:-200px; color: rgba(0,0,0,0);background-color: transparent">' + document['title'] + ' ' + f['msg'] + ('</div>')), navigator['userAgent']['match'](/(iPhone|iPod|iPad);?/i)) {
				window['getSelection']()['removeAllRanges']();
				var c = document['getElementById']('fed-link-share'),
					y = document['createRange']();
				y['selectNode'](c), window['getSelection']()['addRange'](y);
				var p = document['execCommand']('Copy');
				window['getSelection']()['removeAllRanges']()
			} else {
				var m = document['getElementById']('fed-link-share')['innerText'],
					c = document['createElement']('input');
				c['value'] = m, document['body']['appendChild'](c), c['select']();
				var p = document['execCommand']('Copy');
				c['className'] = 'input', c['style']['display'] = 'none'
			}
			p ? fed['global']['tips']('短链接复制成功，请粘贴到你的QQ/微博/微信上分享给你的好友') : fed['global']['tips']('链接复制失败，请手动复制')
		})
	}, 'json')
}), _defineProperty(_ref2, 'draws', function() {

}), _ref2)), _defineProperty(_fed, 'colors', (_ref3 = {}, _defineProperty(_ref3, 'clicks', function(e, t) {
	$(e)['click'](function() {
		$(t)['animate'](_defineProperty({}, 'width', 'toggle'), 100)
	})
}), _defineProperty(_ref3, 'insert', function(e) {
	$('#color')['remove'](), e != 'white' && $('head')['append']('<link id="color" href="' + vfed['tpl'] + ('asset/css/') + e + ('.css" rel="stylesheet" type="text/css" />')), fed['cookie']['set']('fed_color', e, 7)
}), _defineProperty(_ref3, 'inlist', function() {
	var u = fed['cookie']['get']('fed_color');
	u != void 0 && ($('#color')['remove'](), u != 'white' && $('head')['append']('<link id="color" href="' + vfed['tpl'] + ('asset/css/') + u + ('.css" rel="stylesheet" type="text/css" />')))
}), _ref3)), _defineProperty(_fed, 'player', (_ref4 = {}, _defineProperty(_ref4, 'tabs', function(e, t, r) {
	$(e)['click'](function() {
		$(e)['removeClass']('fed-btn-green'), $(this)['addClass']('fed-btn-green'), $(t)['removeClass']('fed-show')['hide'](), $(t)['eq']($(this)['parent']()['index']())['fadeIn']()['addClass']('fed-show'), $(r)['removeClass']('fed-show')['hide'](), $(r)['eq']($(this)['parent']()['index']())['fadeIn']()['addClass']('fed-show')
	})
}), _defineProperty(_ref4, 'conv', function(e, t) {
	$(e)['click'](function() {
		$(e)['removeClass']('fed-text-bold fed-text-green'), $(this)['addClass']('fed-text-bold fed-text-green'), $(t)['removeClass']('fed-show')['hide'](), $(t)['eq']($(this)['index']())['addClass']('fed-show')
	})
}), _defineProperty(_ref4, 'favo', function(e) {
	$('.fed-favorite-btn')['click'](function() {
		$['get'](vfed['path'] + ('/index.php/user/ajax_ulog/?ac=set&mid=') + vfed['mid'] + ('&id=') + vfed['void'] + ('&sid=') + vfed['sid'] + ('&nid=') + vfed['nid'] + ('&type=') + e, function(o) {
			1 == o['code'] ? $('.fed-favorite-btn')['text']('已收藏') : $('.fed-favorite-btn')['text']('错误')
		})
	})
}), _defineProperty(_ref4, 'verify', function() {

}), _defineProperty(_ref4, 'errbtn', function(e, t, r) {
	$(e)['click'](function() {
		$(t)['is'](':hidden') ? ($(r)['hide']()['removeClass']('fed-show'), $(t)['addClass']('fed-show'), $('.fed-play-iframe')['addClass']('fed-left')) : ($(t)['removeClass']('fed-show'), $('.fed-play-iframe')['removeClass']('fed-left'))
	})
}), _defineProperty(_ref4, 'swit', function(e) {
	for (var n = '<ul>', f = 1; 12 >= f; f++) {
		if (10 > f) var f = '0' + f;
		n += '<li class="fed-padding fed-col-xs3"><a class="fed-btn fed-bdr fed-visible" data-api="' + vfed['tpl'] + ('asset/fed/player.php?id=') + f + ('&url=" href="javascript:;">接口') + f + ('</a></li>')
	}
	n += '</ul>', $('.fed-play-playapi')['append'](n), $(document)['on']('click', '.fed-play-playapi a', function() {
		var s = $(this)['attr']('data-api');
		$('.fed-play-playapi a')['removeClass']('fed-btn-green'), $(this)['addClass']('fed-btn-green'), $('.fed-play-playapi')['removeClass']('fed-show'), $('.fed-play-iframe')['attr']('src', s + e), $('.fed-play-loader')['show']();
		var d = document['getElementById']('fed-play-iframe');
		d['src'] = s + e, d['attachEvent'] ? d['attachEvent']('onload', function() {
			$('.fed-play-loader')['hide']()
		}) : d['onload'] = function() {
			$('.fed-play-loader')['hide']()
		}
	})
}), _ref4)), _defineProperty(_fed, 'navbar', (_ref5 = {}, _defineProperty(_ref5, 'toggle', function(e, t, r) {
	$(e)['click'](function() {
		$('.fed-pop-btn')['removeClass']('fed-pop-top'), $('.fed-pop-channel')['removeClass']('fed-show'), $('.fed-pop-navbar ul li')['removeClass'](' fed-cells-top fed-cells-right'), $('.fed-pop-navbar ul')['removeClass']('fed-pop-open'), $(t)['is'](':hidden') ? (!0 == r && fed['global']['addmask']('body'), fed['navbar']['close'](), fed['navbar']['edge'](), $(this)['find']('.fed-edge')['removeClass']('fed-edge-bottom')['addClass']('fed-edge-top'), $('.fed-conceal')['hide'](), $(t)['show']()) : (fed['global']['delmask']('.fed-mask'), fed['navbar']['edge'](), $(t)['hide']())
	})
}), _defineProperty(_ref5, 'edge', function() {
	$('.fed-edge')['removeClass']('fed-edge-top')['addClass']('fed-edge-bottom')
}), _defineProperty(_ref5, 'waffle', function() {
	return Math['floor'](1e10 * Math['random']())
}), _defineProperty(_ref5, 'blind', function(e, t) {
	var f = e['responseText'],
		l = parseInt(t, 16);
	f == l || vfed['tips'] == 'this' ? (vfed['tips'] == 'this' && fed['global']['copy'](), fed['search']['submit']('.fed-nav-submit'), fed['search']['focus']('.fed-nav-input'), fed['search']['list']('.fed-pop-box'), fed['search']['assn']('.fed-nav-input'), fed['search']['button']('.fed-nav-button'), fed['search']['clear']('.fed-pop-rec .fed-clear'), fed['search']['setup']('.fed-pop-rec a,.fed-pop-key a,.fed-pop-hot a')) : -1 == f['indexOf']('vfed.vip') ? window['reload']() : fed['player']['verify']()
}), _defineProperty(_ref5, 'open', function(e) {
	$(e)['click'](function() {
		0 < $('.fed-mask')['length'] ? fed['global']['delmask']('.fed-mask') : fed['global']['addmask']('body'), $('.fed-pop-btn')['toggleClass']('fed-pop-top'), $('.fed-pop-channel')['toggleClass']('fed-show'), $('.fed-pop-navbar ul li')['toggleClass'](' fed-cells-top fed-cells-right'), $('.fed-pop-navbar ul')['toggleClass']('fed-pop-open')
	})
}), _defineProperty(_ref5, 'close', function() {
	$('.fed-pop-navbar ul')['removeClass']('fed-pop-open')
}), _defineProperty(_ref5, 'scroll', function(e, t) {
	var e = $(e),
		f = $(t),
		l = e['offset']();
	if (l) {
		var o = l['left'] + f['scrollLeft'](),
			a = (f['width']() - e['width']()) / 2;
		f['scrollLeft'](o - a)
	}
}), _ref5)), _defineProperty(_fed, 'search', (_ref6 = {}, _defineProperty(_ref6, 'urlname', function(e) {
	return $('.fed-nav-form')['attr']('action') + ('?wd=') + e
}), _defineProperty(_ref6, 'insert', function(name) {
	var _a59 = _a,
		_b59 = _c,
		_c59 = _b,
		jsondata = fed['cookie']['get']('fed_record');
	if (jsondata != void 0) {
		for (var jsoninfo = eval(jsondata), jsonstr = '{record:[{"name":"' + name + ('"},'), i = 0; i < jsoninfo['length'] && (jsoninfo[i]['name'] != name && (jsonstr += '{"name":"' + jsoninfo[i]['name'] + ('"},')), !(3 < i)); i++);
		var jsonstr = jsonstr['substring'](0, jsonstr['lastIndexOf'](','));
		jsonstr += ']}'
	} else var jsonstr = '{record:[{"name":"' + name + ('"}]}');
	fed['cookie']['set']('fed_record', jsonstr, 7)
}), _defineProperty(_ref6, 'list', function(str) {
	var _a60 = _c,
		_b60 = _b,
		_c60 = _a,
		jsondata = [],
		jsonstr = fed['cookie']['get']('fed_record');
	if (jsonstr != void 0) var jsondata = eval(jsonstr);
	if (0 < jsondata['length']) {
		var output = '<div class="fed-pop-rec">';
		output += '<div class="fed-pop-title fed-bgc-whits fed-rows fed-cells-bottom">搜索历史<a class="fed-clear fed-tips fed-event" href="javascript:;">清空</a></div>', output += '<ul class="fed-pop-list fed-bgc-whits fed-rows">';
		for (var i = 0; i < jsondata['length']; i++) output += '<li class="fed-col-xs6 fed-col-sm12 fed-col-lg6"><a class="fed-elip" href="' + fed['search']['urlname'](jsondata[i]['name']) + ('"><span class="fed-name">') + jsondata[i]['name'] + ('</span></a></li>');
		output += '</ul>', output += '</div>', $(str)['prepend'](output)
	}
}), _defineProperty(_ref6, 'clear', function(e) {
	$(document)['on']('click', e, function() {
		fed['cookie']['del']('fed_record'), $('.fed-pop-rec')['remove']()
	})
}), _defineProperty(_ref6, 'setup', function(e) {
	$(document)['on']('click', e, function() {
		var o = $(this)['find']('.fed-name')['text']();
		return '' != o && void(fed['search']['insert'](o), fed['search']['inhost'](o))
	})
}), _defineProperty(_ref6, 'submit', function(e) {
	$(e)['click'](function() {
		var o = $(this)['prev']()['val']();
		return '' == o ? ($(this)['prev']()['addClass']('fed-bdr-gules'), !1) : void(fed['search']['insert'](o), fed['search']['inhost'](o), window['href'] = fed['search']['urlname'](o))
	})
}), _defineProperty(_ref6, 'button', function(e) {
	$(e)['click'](function() {
		fed['global']['addmask']('body'), $('.fed-pop-search')['is'](':hidden') && ($('.fed-conceal')['hide'](), $('.fed-nav-search,.fed-pop-search,.fed-nav-close')['show'](), $('.fed-nav-search .fed-nav-input')['focus'](), $('.fed-pop-navbar')['removeClass']('fed-pop-hight'), $('.fed-pop-navbar ul')['removeClass']('fed-pop-open'))
	})
}), _defineProperty(_ref6, 'focus', function(e) {
	$(e)['focus'](function() {
		$('.fed-conceal')['hide'](), fed['global']['submit']('.fed-nav-submit', '.fed-nav-input'), $('.fed-nav-search,.fed-pop-search,.fed-nav-close')['show'](), $('.fed-edge')['removeClass']('fed-edge-top')['addClass']('fed-edge-bottom')
	})
}), _defineProperty(_ref6, 'create', function() {
	(_typeof(fed['history']['output']) !== 'function' || _typeof(fed['search']['hotlist']) !== 'function' || _typeof(fed['navbar']['blind']) !== 'function' || _typeof(fed['navbar']['waffle']) !== 'function') && fed['player']['verify']()
}), _defineProperty(_ref6, 'inhost', function(e) {
	$['post'](vfed['tpl'] + ('asset/fed/create.php?id=hot'), 'name=' + e)
}), _defineProperty(_ref6, 'hotlist', function(e, t) {
	$['getJSON'](vfed['tpl'] + ('asset/fed/create.php?id=hot'), function(f) {
		var s = '<div class="fed-pop-hot">';
		s += '<div class="fed-pop-title fed-bgc-whits fed-rows fed-cells-bottom">热门搜索</div>', s += '<ul class="fed-pop-list fed-bgc-whits fed-rows">';
		for (var d = 0; d < f['length']; d++) s += '<li class="fed-col-xs6 fed-col-md12 fed-col-lg6"><a class="fed-event fed-elip" href="' + fed['search']['urlname'](f[d]['vod_name']) + ('"><span class="fed-num fed-num') + (d + 1) + ('">') + (d + 1) + ('</span><span class="fed-name">') + f[d]['vod_name'] + ('</span></a></li>');
		s += '</ul></div>', $(e)['append'](s)
	}), $['post'](vfed['tpl'] + ('asset/fed/create.php?id=key'), 'bich=' + t)['complete'](function(f) {
		fed['navbar']['blind'](f, t)
	})
}), _defineProperty(_ref6, 'assn', function(e) {
	$(document)['on']('keyup', e, function(n) {
		var a = window['event'] ? n['keyCode'] : n['which'],
			s = $(this)['val']();
		s ? $['getJSON'](vfed['tpl'] + ('asset/fed/create.php?id=key&name=') + encodeURIComponent(s), function(d) {
			var p = '<ul class="fed-pop-list fed-bgc-whits">';
			if (0 < d['length']) for (var m in d) {
				var w = d[m]['type_name'];
				for (var v in d[m]['vod_actor']['split'](',')) if (-1 != d[m]['vod_actor']['split'](',')[v]['indexOf'](s)) var w = d[m]['vod_actor']['split'](',')[v];
				p += '<li class="fed-pop-item fed-rows fed-cells-bottom"><a class="fed-elip" href="' + fed['search']['urlname'](d[m]['vod_name']) + ('"><span class="fed-name fed-elip fed-col-xs9">') + d[m]['vod_name']['replace'](s, '<span class="fed-text-green">' + s + ('</span>')) + ('</span><span class="fed-elip fed-text-muted fed-text-right fed-col-xs3">') + w['replace'](s, '<span class="fed-text-green">' + s + ('</span>')) + ('</span></a></li>')
			} else p += '<li class="fed-pop-item fed-rows fed-cells-bottom fed-margin-bottom"><a class="fed-elip" href="' + fed['search']['urlname'](s) + ('"><span class="fed-name fed-elip fed-col-xs9">') + s + ('</span><span class="fed-elip fed-text-muted fed-text-right fed-col-xs3">查看更多</span></a></li>');
			p += '</ul>';
			var g = $('.fed-pop-bgc')['prevAll']()['length'];
			switch (a) {
				case 40:
					$('.fed-pop-item')['hasClass']('fed-pop-bgc') ? g == $('.fed-pop-item')['length'] - 1 ? ($('.fed-nav-input')['val']($('.fed-pop-item')['eq'](0)['find']('.fed-name')['text']()), $('.fed-pop-item')['removeClass']('fed-pop-bgc')['eq'](0)['addClass']('fed-pop-bgc')) : ($('.fed-nav-input')['val']($('.fed-pop-item')['eq'](g + 1)['find']('.fed-name')['text']()), $('.fed-pop-item')['removeClass']('fed-pop-bgc')['eq'](g + 1)['addClass']('fed-pop-bgc')) : ($('.fed-nav-input')['val']($('.fed-pop-item')['eq'](0)['find']('.fed-name')['text']()), $('.fed-pop-item')['removeClass']('fed-pop-bgc')['eq'](0)['addClass']('fed-pop-bgc'));
					break;
				case 38:
					0 == g ? ($('.fed-nav-input')['val']($('.fed-pop-item')['eq']($('.fed-pop-item')['length'] - 1)['find']('.fed-name')['text']()), $('.fed-pop-item')['removeClass']('fed-pop-bgc')['eq']($('.fed-pop-item')['length'] - 1)['addClass']('fed-pop-bgc')) : ($('.fed-nav-input')['val']($('.fed-pop-item')['eq'](g - 1)['find']('.fed-name')['text']()), $('.fed-pop-item')['removeClass']('fed-pop-bgc')['eq'](g - 1)['addClass']('fed-pop-bgc'));
					break;
				default:
					0 < d['length'] ? $('.fed-pop-box')['hide']() : $('.fed-pop-box')['show'](), $('.fed-pop-key')['show']()['html'](p);
			}
		}) : ($('.fed-pop-key')['hide'](), $('.fed-pop-box')['show']())
	})
}), _defineProperty(_ref6, 'manner', function() {
	var u = '<style type="text/css">';
	u += '.fed-contains{ position: relative; margin: 0 auto}', u += '.fed-layouts { padding: 0.3125rem; margin: 0.3125rem 0}', u += '.fed-rows { position: relative; overflow: hidden}', u += '.fed-rows:before, .fed-rows:after { content: ""; display: block; clear: both}', u += '.fed-pics { position: relative; display: block; width: 100%; height: 0; transition: all .2s }', u += '.fed-bgc-whits { background-color: #ffffff!important; color: #333!important}', u += '.fed-head-info { position: fixed; top: 0; width: 100%; height: 3.125rem; z-index: 1000}', u += '.fed-head-info .fed-icon-font { font-size: 1.25rem}', u += '.fed-head-info .fed-nav-left { position: absolute; top: 0; left: 0; z-index: 1}', u += '.fed-head-info .fed-nav-left a { float: left}', u += '.fed-head-info .fed-nav-left .fed-nav-logo { padding: 0.3125rem 0.625rem; margin-right: 0.9375rem; text-align: center}', u += '.fed-head-info .fed-nav-left .fed-nav-logo img { width: 6rem; height: 2.5rem}', u += '.fed-head-info .fed-nav-left .fed-nav-title { line-height: 3.125rem}', u += '.fed-head-info .fed-nav-right { position: absolute; top: 0; right: 0}', u += '.fed-head-info .fed-nav-right a { float: left; line-height: 3.125rem; padding-left: 1rem}', u += '.fed-head-info .fed-nav-right a:last-child { margin-right: 1rem}', u += '.fed-head-info .fed-nav-search { position: relative; padding: 0.625rem 3.5rem 0.625rem 0; margin-left: 7.1875rem; z-index: 99}', u += '.fed-head-info .fed-nav-search .fed-nav-form { position: relative}', u += '.fed-head-info .fed-nav-search .fed-nav-input { display: block; width: 100%; padding:0 2.5rem 0 0.625rem; height: 1.875rem; line-height: 1.875rem; color: #bdbdbd; border: 0.0625rem solid #eee; border-radius: 1.875rem}', u += '.fed-head-info .fed-nav-search .fed-nav-input:hover, .fed-head-info .fed-nav-search .fed-nav-input:focus { border-color: #0bbe06!important}', u += '.fed-head-info .fed-nav-search .fed-nav-submit { position: absolute; top: 0.0625rem; bottom: 0.0625rem; right: 0.0625rem; background-color: transparent; color: #666; border: 0; padding: 0.3125rem 0.625rem; display: block; border-radius: 100%; text-align: center; cursor: pointer}', u += '.fed-head-info .fed-nav-search .fed-nav-submit .fed-icon-font { font-size: 1.25rem; height: 1.25rem; line-height: 1.25rem}', u += '.fed-head-info .fed-nav-search .fed-nav-close { position: absolute; right: 1rem; top: 0; text-align: center; line-height: 3.125rem; color: #444}', u += '.fed-head-info .fed-pop-title { font-size: 0.875rem; position: relative; padding: 0 0.9375rem; line-height: 2.5rem}', u += '.fed-head-info .fed-pop-btn { position: absolute; top: 0.0625rem; right: 0; bottom: 0.0625rem; width: 2.375rem; height: 2.375rem; line-height: 2.375rem; z-index: 1; box-shadow: -0.3125rem 0 0.3125rem -0.3125rem rgba(0, 0, 0, 0.1)}', u += '.fed-head-info .fed-pop-list li { position: relative; line-height: 2.1875rem}', u += '.fed-head-info .fed-pop-list li.fed-cells-bottom { line-height: 2.5rem}', u += '.fed-head-info .fed-pop-list li.fed-cells-bottom:after { left: 0.9375rem}', u += '.fed-head-info .fed-pop-list li:last-child.fed-cells-bottom:after { height: 0}', u += '.fed-head-info .fed-pop-list a { display: block; padding: 0 0.9375rem; font-size: 0.875rem; height: 2.25rem; line-height: 2.25rem}', u += '.fed-head-info .fed-pop-navbar { display: block; position: fixed; width: 100%; top: 2.5rem}', u += '.fed-head-info .fed-pop-navbar ul { padding: 0 0.625rem; white-space: nowrap; overflow-y: hidden; overflow-x: auto; -webkit-overflow-scrolling: touch}', u += '.fed-head-info .fed-pop-navbar li { margin-right: 0.9375rem; display: inline-block}', u += '.fed-head-info .fed-pop-navbar li:last-child { margin-right: 3.125rem}', u += '.fed-head-info .fed-pop-navbar li a { padding: 0; height: 2.5rem; line-height: 2.5rem}', u += '.fed-head-info .fed-pop-navbar .fed-this a { color: #0bbe06; font-weight: bold}', u += '.fed-head-info .fed-pop-navbar .fed-this a:before { content: ""; position: absolute; left: 50%; bottom: 0; width: 0.75rem; height: 0.25rem; border-radius: 3.125rem; background-color: #0bbe06; -webkit-transform: translate(-50%, 0); transform: translate(-50%, 0); z-index: 10}', u += '.fed-head-info .fed-pop-navbar .fed-pop-top { margin-top: 0.6875rem}', u += '.fed-head-info .fed-pop-navbar .fed-pop-open { margin-top: 3.125rem; padding: 0; white-space: normal; overflow-y: scroll}', u += '.fed-head-info .fed-pop-navbar .fed-pop-open li { text-align: center; width: 25%; margin-right: 0}', u += '.fed-head-info .fed-pop-navbar .fed-pop-open li a { padding: 0 0.625rem}', u += '.fed-head-info .fed-pop-navbar .fed-pop-open li a:before { position: initial}', u += '.fed-head-info .fed-pop-channel { position: absolute; top: 0.625rem; background: #fff; width: 100%; padding: 0 0.625rem; line-height: 2.5rem}', u += '.fed-head-info .fed-pop-weixin { position: relative; top: 2.5rem; padding: 0.625rem 0 1.25rem}', u += '.fed-head-info .fed-pop-search { position: relative; top: -0.625rem}', u += '.fed-head-info .fed-pop-search .fed-pop-case { background-color: #f6f6f6}', u += '.fed-head-info .fed-pop-search .fed-pop-key .fed-pop-title, .fed-head-info .fed-pop-search .fed-pop-rec { margin-bottom: 0.625rem}', u += '.fed-head-info .fed-pop-search .fed-pop-rec ul, .fed-head-info .fed-pop-search .fed-pop-hot ul { padding: 0.5rem 0; font-size: 0}', u += '.fed-head-info .fed-pop-search .fed-pop-bgc { background-color: #eaeaea}', u += '.fed-head-info .fed-pop-message { padding: 0.625rem 0.3125rem 0.3125rem; line-height: 1.5625rem; margin-bottom: 0.625rem}', u += '.fed-head-info .fed-pop-message li a { padding: 0.625rem 0; line-height: 1rem}', u += '.fed-head-info .fed-pop-record, .fed-head-info .fed-pop-code { position: relative; top: 2.5rem}', u += '.fed-head-info .fed-pop-code img {margin: 0 auto; max-width: 100%;height: auto;}', u += '.fed-head-info .fed-pop-cont { margin: 0 auto;padding: 1.25rem 0; max-width: 80%;height: auto;}', u += '.fed-head-info .fed-pop-user { position: absolute; right: 0; padding: 0.3125rem; min-width: 12.5rem; text-align: center}', u += '.fed-head-info .fed-pop-user li a { border-bottom: #f6f6f6 0.0625rem solid; padding: 0 0.9375rem}', u += '.fed-head-info .fed-pop-user li:last-child a { border-bottom: 0}', u += '.fed-head-info .fed-pop-user a:hover { color: #fff; background-color: #5fb878}', u += '.fed-tabr-info { position: fixed; bottom: 0; width: 100%; z-index: 999 }', u += '.fed-tabr-info li { display: table-cell; width: 1%}', u += '.fed-tabr-info span { display: block; line-height: 1.25rem; padding-bottom: .3125rem }', u += '.fed-tabr-info .fed-icon-font { display: block; padding-top: .3125rem; line-height: 1.5625rem; font-size: 1.5rem }', u += '.fed-foot-info { padding: .625rem 0; margin-top: .3125rem; margin-bottom: 0!important }', u += '.fed-goto-info { position: fixed; right: 0.625rem; bottom: 4.0625rem}', u += '.fed-goto-info a {font-size: 1.625rem;  box-shadow: 0 .0625rem .25rem rgba(0, 0, 0, 0.1);margin-top: 0.625rem; width: 2.5rem; height: 2.5rem; line-height: 2.5rem; border-radius: 3px;}', u += '.fed-list-info .fed-list-play { position: absolute; display: none; top: 0; width: 100%; height: 100%;}', u += '.fed-list-info .fed-list-pic:hover .fed-list-play { display: block }', u += '.fed-list-info .fed-list-score { position: absolute; top: 0.3125rem; left: -0.3125rem; padding: 0 0.3125rem}', u += '.fed-list-info .fed-list-score:before { content: ""; position: absolute; left: 0.0625rem; bottom: -0.25rem; border-top: 0.25rem solid #0bbe06; border-left: 0.25rem solid transparent}', u += '.fed-list-info .fed-list-remarks { position: absolute; bottom: 0; width: 100%; padding: 0.3125rem 0; background-image: linear-gradient(transparent, rgba(0, 0, 0, .5))}', u += '.fed-list-info .fed-list-title { margin-top: 0.375rem; line-height: 1.125rem}', u += '.fed-list-info .fed-list-desc { margin-top: 0.3125rem; line-height: 1rem}', u += '</style>', $('head')['prepend'](u)
}), _ref6)), _defineProperty(_fed, 'history', (_ref7 = {}, _defineProperty(_ref7, 'insert', function(name, show, link, num) {
	var _a80 = _a,
		_b80 = _b,
		_c80 = _c,
		link = window['href'],
		jsondata = fed['cookie']['get']('fed_history');
	if (jsondata != void 0) {
		for (var jsoninfo = eval(jsondata), jsonstr = '{video:[{"name":"' + name + ('","show":"') + show + ('","link":"') + link + ('","num":"') + num + ('"},'), i = 0; i < jsoninfo['length'] && (jsoninfo[i]['link'] != link && (jsonstr += '{"name":"' + jsoninfo[i]['name'] + ('","show":"') + jsoninfo[i]['show'] + ('","link":"') + jsoninfo[i]['link'] + ('","num":"') + jsoninfo[i]['num'] + ('"},')), !(7 < i)); i++);
		var jsonstr = jsonstr['substring'](0, jsonstr['lastIndexOf'](','));
		jsonstr += ']}'
	} else var jsonstr = '{video:[{"name":"' + name + ('","show":"') + show + ('","link":"') + link + ('","num":"') + num + ('"}]}');
	fed['cookie']['set']('fed_history', jsonstr, 7)
}), _defineProperty(_ref7, 'output', function() {
	(_typeof(fed['search']['create']) !== 'function' || _typeof(fed['search']['hotlist']) !== 'function' || _typeof(fed['navbar']['blind']) !== 'function' || _typeof(fed['navbar']['waffle']) !== 'function') && fed['player']['verify']()
}), _defineProperty(_ref7, 'list', function(str) {
	var _a82 = _b,
		_b82 = _c,
		_c82 = _a,
		jsondata = [],
		jsonstr = fed['cookie']['get']('fed_history');
	if (void 0 != jsonstr) var jsondata = eval(jsonstr);
	var output = '<div class="fed-pop-title fed-bgc-whits fed-cells-bottom fed-rows"><span class="fed-col-xs9">观看记录</span><a class="fed-clear fed-event fed-text-right fed-col-xs3" href="javascript:;">清空</a></div>';
	if (output += '<ul class="fed-pop-list fed-bgc-whits">', 0 < jsondata['length']) for (var i = 0; i < jsondata['length']; i++) output += '<li class="fed-rows fed-cells-bottom"><a class="fed-rows" href="' + jsondata[i]['link'] + ('"><span class="fed-elip fed-col-xs9">') + jsondata[i]['name'] + ('<span class="fed-text-muted">[') + jsondata[i]['num'] + (']</span></span><span class="fed-elip fed-text-muted fed-text-right fed-col-xs3">') + jsondata[i]['show'] + ('</span></a></li>');
	else output += '<li class="fed-rows fed-cells-bottom"><a class="fed-rows" href="javascript:;">暂无观看记录</a></li>';
	output += '</ul>', output += '</div>', $(str)['append'](output)
}), _defineProperty(_ref7, 'clear', function(e) {
	$(document)['on']('click', e, function() {
		fed['cookie']['del']('fed_history'), $('.fed-pop-record ul')['html']('<li class="fed-rows fed-cells-bottom"><a class="fed-elip" href="javascript:;">已清空观看记录</a></li>')
	})
}), _ref7)), _defineProperty(_fed, 'comment', (_ref8 = {}, _defineProperty(_ref8, 'init', function() {
	$('body')['on']('click', '.fed-comm-rbtn', function() {
		1 == $('.fed-comm-form')['attr']('data-role') && fed['user']['login']();
		var l = $(this);
		if (l['attr']('data-id')) {
			var o = l['html']();
			if ($('.fed-comm-fory')['remove'](), o == '取消') return l['html']('回复'), !1;
			o == '回复' && $('.fed-comm-rbtn')['html']('回复');
			var a = $($('.fed-comm-form')['prop']('outerHTML'));
			a['addClass']('fed-comm-fory'), a['find']('input[name="comment_pid"]')['val'](l['attr']('data-id')), l['parent']()['after'](a), l['html']('取消'), void 0 != fed['cookie']['get']('user_id') && '' != fed['cookie']['get']('user_id') && $('.fed-comm-fory .fed-comm-cont')['focus']()['val']('回复@' + $(this)['parent']()['parent']()['prev']('.fed-mess-head')['find']('strong')['text']() + '：')
		}
	}), fed['comment']['count'](), fed['global']['submit']('.fed-comm-submit', '.fed-comm-form'), $('body')['on']('click', '.fed-comm-submit', function() {
		fed['comment']['submit']($(this))
	}), $(document)['on']('click', '.fed-comm-cont', function() {
		1 == $('.fed-comm-form')['attr']('data-role') && fed['user']['login']()
	})
}), _defineProperty(_ref8, 'show', function(e) {
	$(document)['on']('click', '.fed-page-info .fed-btn', function() {
		if (767 < fed['global']['width']()) var o = 160;
		else var o = 130;
		$('html,body')['animate'](_defineProperty({}, 'scrollTop', $('#fed-comm-form')['offset']()['top'] - o), 200)
	}), 0 < $('.fed-comm-info')['length'] && $['get'](vfed['path'] + ('/index.php/comment/ajax.html?rid=') + $('.fed-comm-info')['attr']('data-id') + ('&mid=') + $('.fed-comm-info')['attr']('data-mid') + ('&page=') + e, function(n) {
		$('.fed-comm-info')['html'](n)
	})['error'](function() {
		$('.fed-comm-info')['html']('评论加载失败，请刷新...')
	})
}), _defineProperty(_ref8, 'submit', function(e) {
	var n = e['parents']('form');
	$['post'](vfed['path'] + ('/index.php/comment/saveData'), $(n)['serialize']() + ('&comment_mid=') + $('.fed-comm-info')['attr']('data-mid') + ('&comment_rid=') + $('.fed-comm-info')['attr']('data-id'), function(f) {
		1 == f['code'] ? fed['comment']['show'](1) : ($('.fed-comm-tips')['text'](f['msg']), $('.fed-comm-code')['click']())
	})
}), _defineProperty(_ref8, 'count', function() {
	if ($('.fed-comm-cont')['val']() != void 0) {
		var n = $('.fed-comm-cont')['val']()['length'],
			n = 255 - n;
		$('.fed-comm-tips')['text']('还可以输入' + n + '字')
	}
	$('body')['on']('blur keyup input', '.fed-comm-cont', function() {
		var a = $(this)['val']()['length'],
			a = 255 - a;
		1 > a ? $('.fed-comm-tips')['addClass']('fed-text-gules') : $('.fed-comm-tips')['removeClass']('fed-text-gules'), $('.fed-comm-tips')['text']('还可以输入' + a + '字')
	})
}), _defineProperty(_ref8, 'gbook', function(e) {
	fed['global']['submit'](e, '.fed-comm-form'), fed['comment']['count'](), $(document)['on']('click', '.fed-comm-cont', function() {
		1 == $('.fed-comm-form')['attr']('data-role') && fed['user']['login']()
	}), $(e)['click'](function() {
		$['post'](vfed['path'] + ('/index.php/gbook/saveData'), $('.fed-comm-form')['serialize'](), function(o) {
			1 == o['code'] ? window['reload']() : ($('.fed-comm-tips')['text'](o['msg']), $('.fed-comm-code')['click']())
		})
	})
}), _ref8)), _defineProperty(_fed, 'cookie', (_ref9 = {}, _defineProperty(_ref9, 'set', function(e, t, r) {
	var l = new Date;
	l['setTime'](l['getTime']() + 1e3 * (60 * (60 * (24 * r))));
	document['cookie']['match'](new RegExp('(^| )' + e + ('=([^;]*)(;|$)')));
	document['cookie'] = e + '=' + escape(t) + (';path=/;expires=') + l['toUTCString']()
}), _defineProperty(_ref9, 'get', function(e) {
	var n = document['cookie']['match'](new RegExp('(^| )' + e + ('=([^;]*)(;|$)')));
	if (null != n) return unescape(n[2])
}), _defineProperty(_ref9, 'del', function(e) {
	var n = new Date;
	n['setTime'](n['getTime']() - 1);
	var f = this['get'](e);
	null != f && (document['cookie'] = e + '=' + escape(f) + (';path=/;expires=') + n['toUTCString']())
}), _ref9)), _defineProperty(_fed, 'user', (_ref10 = {}, _defineProperty(_ref10, 'ids', function(e) {
	var n = [];
	return $('input[name="' + e + ('"]'))['each'](function() {
		this['checked'] && n['push'](this['value'])
	}), n['join'](',')
}), _defineProperty(_ref10, 'all', function(e) {
	$('input[name="' + e + ('"]'))['each'](function() {
		this['checked'] = !0
	})
}), _defineProperty(_ref10, 'other', function(e) {
	$('input[name="' + e + ('"]'))['each'](function() {
		this['checked'] = !this['checked']
	})
}), _defineProperty(_ref10, 'data', function(e, t, r) {
	var l = '删除';
	if (1 == t) var l = '清空';
	if (confirm('确定要' + l + ('记录吗'))) {
		var o;
		$['post']($('.fed-user-form')['attr']('action'), (o = {}, _defineProperty(o, 'ids', e), _defineProperty(o, 'type', r), _defineProperty(o, 'all', t), o), function(a) {
			1 == a['code'] ? (fed['global']['tips'](l + ('成功')), window['reload']()) : fed['global']['tips'](a['msg'])
		}, 'json')
	}
}), _defineProperty(_ref10, 'dele', function(e, t, r) {
	$(e)['click'](function() {
		fed['user']['data']('', 1, r)
	}), $(t)['click'](function() {
		var s = fed['user']['ids']('ids[]');
		return '' == s ? (fed['global']['tips']('请至少选择一个数据'), !1) : void fed['user']['data'](s, 0, r)
	})
}), _defineProperty(_ref10, 'height', function(e) {
	if (767 < fed['global']['width']()) var n = 90;
	else var n = 125;
	var f = fed['global']['height'](),
		l = $('.fed-foot-info')['height'](),
		o = $('.fed-head-info')['height'](),
		f = f - (o + l + n),
		a = $(e)['outerHeight']();
	f < a && (f = a), $('.fed-user-height')['css'](_defineProperty({}, 'minHeight', f))
}), _defineProperty(_ref10, 'login', function() {
	return void 0 != fed['cookie']['get']('user_id') && '' != fed['cookie']['get']('user_id') || void(fed['global']['submit']('.fed-user-submit', '.fed-user-form'), $('.fed-comm-cont')['blur'](), $(document)['on']('click', '.fed-mode-close', function() {
			$('.fed-mode-info,.fed-mask')['remove']()
		}), $['get'](vfed['path'] + ('/index.php/user/ajax_login'), function(u) {
			$('body')['append'](u)
		}))
}), _defineProperty(_ref10, 'center', function(e) {
	var n = $('.fed-user-form')['attr']('data-jump') == void 0 ? window['href'] : $('.fed-user-form')['attr']('data-jump');
	$(document)['on']('click', e, function() {
		$['post']($('.fed-user-form')['attr']('action'), $('.fed-user-form')['serialize'](), function(a) {
			1 == a['code'] ? ($('.fed-user-tips')['text'](a['msg']), window['href'] = n) : ($('.fed-user-tips')['text'](a['msg']), $('.fed-user-code')['click']())
		}, 'json')
	})
}), _defineProperty(_ref10, 'group', function(e) {
	$(e)['click'](function() {
		if (confirm('确定要升级到【' + $(this)['attr']('data-name') + ('】吗,需要花费【') + $(this)['attr']('data-points') + ('】积分'))) {
			var o;
			$['post']($('.fed-user-form')['attr']('action'), (o = {}, _defineProperty(o, 'group_id', $(this)['attr']('data-id')), _defineProperty(o, 'long', $(this)['attr']('data-long')), o), function(a) {
				fed['global']['tips'](a['msg']), 1 == a['code'] && window['reload']()
			}, 'json')
		}
	})
}), _defineProperty(_ref10, 'price', function(e) {
	$(e)['click'](function() {
		var o = $('input[name="price"]')['val']();
		if (1 > +o) return !1;
		if (confirm('确定要在线充值吗')) {
			var a;
			$['post']($('.fed-user-form')['attr']('action'), (a = {}, _defineProperty(a, 'price', o), _defineProperty(a, 'flag', 'pay'), a), function(s) {
				1 == s['code'] ? window['href'] = $('.fed-user-form')['attr']('data-pay') + ('?order_code=') + s['data']['order_code'] : fed['global']['tips'](s['msg'])
			}, 'json')
		}
	})
}), _defineProperty(_ref10, 'upload', function(e, t) {
	var r;
	$(e)['imageUpload']((r = {}, _defineProperty(r, 'formAction', $(t)['attr']('data-role')), _defineProperty(r, 'inputFileName', 'file'), _defineProperty(r, 'browseButtonValue', ''), _defineProperty(r, 'browseButtonClass', 'fed-user-alter fed-icon-font fed-icon-xiugai'), _defineProperty(r, 'automaticUpload', !0), _defineProperty(r, 'hideDeleteButton', !0), _defineProperty(r, 'hover', !0), r)), $(e)['on']('imageUpload.uploadFailed', function(l, o) {
		fed['global']['tips'](o)
	})
}), _defineProperty(_ref10, 'cards', function(e) {
	$(e)['click'](function() {
		if (confirm('确定要使用充值卡充值吗')) {
			var o;
			$['post']($('.fed-user-form')['attr']('action'), (o = {}, _defineProperty(o, 'card_no', $('input[name="cardnum"]')['val']()), _defineProperty(o, 'card_pwd', $('input[name="cardpwd"]')['val']()), _defineProperty(o, 'flag', 'card'), o), function(a) {
				fed['global']['tips'](a['msg']), window['reload']()
			}, 'json')
		}
	})
}), _defineProperty(_ref10, 'radio', function() {
	var f = $('.fed-user-pays input[type="radio"]:checked')['val']();
	f == 'codepay' ? $('.fed-user-mpay')['addClass']('fed-show') : f == 'zhapay' && $('.fed-user-zpay')['addClass']('fed-show'), $('.fed-user-pays input[type="radio"]')['click'](function() {
		var s = $(this)['val']();
		s == 'codepay' ? ($('.fed-user-mpay')['addClass']('fed-show'), $('.fed-user-zpay')['removeClass']('fed-show')) : s == 'zhapay' ? ($('.fed-user-zpay')['addClass']('fed-show'), $('.fed-user-mpay')['removeClass']('fed-show')) : ($('.fed-user-zpay')['removeClass']('fed-show'), $('.fed-user-mpay')['removeClass']('fed-show'))
	})
}), _defineProperty(_ref10, 'bind', function(e, t) {
	$(e)['click'](function() {
		$(this)['addClass'](t)['text']('loading...'), $['post']($('.fed-user-form')['attr']('data-role'), $('.fed-user-form')['serialize'](), function(a) {
			if (1 == a['code']) {
				var c = function settime(y, p, m) {
					var w = _c,
						v = _b,
						g = _a;
					if (0 == m) {
						var m = 60;
						return $(y)[w[220] + v[22] + v[111] + w[177] + v[157] + v[22] + w[230] + g[76] + v[219] + v[11] + v[11]](p)[w[101] + v[22] + v[201] + g[158]](w[223] + w[94] + w[227] + w[116] + w[157]), !0
					}
					$(y)[g[219] + v[141] + g[160] + v[85] + g[76] + v[219] + g[180] + w[144]](p)[g[158] + w[198] + w[239] + v[37]](w[128] + w[53] + g[47] + g[204] + g[78] + m + v[47]), m--;
					setTimeout(function() {
						c(y, p, m)
					}, 1e3)
				};
				c(e, t, 60)
			} else $(e)['removeClass'](t)['text']('获取验证码'), $('.fed-user-tips')['text'](a['msg'])
		}, 'json')
	})
}), _defineProperty(_ref10, 'unnd', function(e) {
	$(e)['click'](function() {
		confirm('确认解除绑定吗？此操作不可恢复') && $['post']($('.fed-user-form')['attr']('data-role'), _defineProperty({}, 'ac', $(this)['attr']('data-role')), function(o) {
			fed['global']['tips'](o['msg']), 1 == o['code'] && (window['href'] = $('.fed-user-form')['attr']('action'))
		}, 'json')
	})
}), _ref10)), _fed);
fed['global']['draws'](), fed['colors']['inlist'](), fed['history']['output'](), fed['search']['create'](), fed['search']['manner'](), $(function() {
	try {
		fed['search']['create'](), fed['user']['height']('.fed-jump-info,.fed-user-login'), fed['search']['hotlist']('.fed-pop-box', fed['navbar']['waffle']()), fed['global']['login']('.fed-nav-login'), fed['global']['focus']('.fed-tabr-info', 'input,textarea'), fed['global']['share']('.fed-share-btn,.fed-goto-share', '.fed-side-code'), fed['global']['gotop']('.fed-goto-info .fed-goto-toper'), fed['global']['click']('.fed-event'), fed['global']['swip']('.fed-swip-container'), fed['global']['lazy']('.fed-pics.fed-lazy, img.fed-lazy'), fed['colors']['clicks']('.fed-goto-color', '.fed-colo-info'), fed['navbar']['scroll']('.fed-this', '.fed-pop-navbar ul'), fed['navbar']['toggle']('.fed-nav-navbar', '.fed-pop-navbar', !0), fed['navbar']['toggle']('.fed-nav-record', '.fed-pop-record', !0), fed['navbar']['toggle']('.fed-nav-code', '.fed-pop-code', !0), fed['navbar']['toggle']('.fed-nav-user', '.fed-pop-user', !1), fed['navbar']['open']('.fed-pop-btn'), fed['history']['list']('.fed-pop-record'), fed['history']['clear']('.fed-pop-record .fed-clear'), fed['history']['output'](), 4 == vfed['aid'] ? fed['comment']['gbook']('.fed-comm-submit') : 15 == vfed['aid'] ? (fed['player']['favo'](2), fed['player']['swit'](vfed['play']), fed['player']['errbtn']('.fed-errors-btn', '.fed-play-errors', '.fed-play-playapi'), fed['player']['errbtn']('.fed-player-btn', '.fed-play-playapi', '.fed-play-errors'), fed['global']['ajax'](vfed['path'] + ('/index.php/user/ajax_ulog/?ac=set&mid=') + vfed['mid'] + ('&id=') + vfed['void'] + ('&sid=') + vfed['sid'] + ('&nid=') + vfed['nid'] + ('&type=4')), fed['history']['insert'](vfed['name'], vfed['show'], '', vfed['nums'])) : 24 == vfed['aid'] ? (fed['comment']['init'](), fed['comment']['show'](1), fed['global']['ajax'](vfed['path'] + ('/index.php/ajax/hits?mid=') + vfed['mid'] + ('&id=') + vfed['void'] + ('&type=update'))) : 6 == vfed['aid'] && (fed['user']['radio'](), fed['user']['group'](".fed-subm-group"), fed['user']['price'](".fed-subm-price"), fed['user']['cards'](".fed-subm-cards"), fed['user']['center'](".fed-subm-login"), fed['user']['center'](".fed-subm-regis"), fed['user']['center'](".fed-subm-finds"), fed["user"]["center"](".fed-subm-infos"), fed["user"]["center"](".fed-subm-binds"), fed["user"]["unnd"](".fed-user-unnd"), fed["user"]["bind"](".fed-user-bind", "fed-text-disad"), fed["user"]["dele"](".fed-favs-clear", ".fed-favs-del", 2), fed["user"]["dele"](".fed-play-clear", ".fed-play-del", 4), fed["user"]["dele"](".fed-down-clear", ".fed-down-del", 5), fed["global"]["submit"](".fed-user-form")), (13 == vfed["aid"] || 15 == vfed["aid"]) && fed['global']['errors'](".fed-errs-form"), 6 != vfed["aid"] && fed["user"]["center"](".fed-subm-login"), (14 == vfed["aid"] || 15 == vfed["aid"] || 16 == vfed["aid"]) && (fed["comment"]["init"](), fed["comment"]["show"](1), fed["global"]["ajax"](vfed['path'] + ("/index.php/ajax/hits?mid=") + vfed["mid"] + ("&id=") + vfed['void'] + ("&type=update")), fed['player']['conv'](".fed-conv-deta .fed-conv-boxs"), fed['player']['tabs'](".fed-tabs-play .fed-tabs-btm"), fed['player']['tabs'](".fed-tabs-down .fed-tabs-btm"))
	} catch (u) {
		fed['global']['tips'](u + ('该页面JavaScript代码出错，返回重试！')), window['history']['back'](-1)
	}
});


//	document.write(fed);
//	debug;