<?php
$jiekouid = @$_GET['id'];
$videourl = @$_GET['url'];
require ('create.php');
loadhead('VIP视频解析');
if (empty($jiekouid)) {
	if ($videourl) {
		if (strstr($videourl, '.qq.com') == true)
			iframe(server('jk01') . $videourl);
		elseif (strstr($videourl, '.youku.com') == true)
			iframe(server('jk02') . $videourl);
		elseif (strstr($videourl, '.sohu.com') == true)
			iframe(server('jk03') . $videourl);
		elseif (strstr($videourl, '.iqiyi.com') == true)
			iframe(server('jk04') . $videourl);
		elseif (strstr($videourl, '.pptv.com') == true)
			iframe(server('jk05') . $videourl);
		elseif (strstr($videourl, '.mgtv.com') == true)
			iframe(server('jk06') . $videourl);
		elseif (strstr($videourl, '.letv.com') == true)
			iframe(server('jk07') . $videourl);
		elseif (strstr($videourl, '.le.com') == true)
			iframe(server('jk07') . $videourl);
		elseif (strstr($videourl, '.wasu.cn') == true)
			iframe(server('jk08') . $videourl);
		elseif (strstr($videourl, '.cctv.com') == true)
			iframe(server('jk09') . $videourl);
		elseif (strstr($videourl, '.1905.com') == true)
			iframe(server('jk10') . $videourl);
		elseif (strstr($videourl, '.bilibili.com') == true)
			iframe(server('jk11') . $videourl);
		elseif (strstr($videourl, '.yinyuetai.com') == true)
			iframe(server('jk12') . $videourl);
		elseif (strstr($videourl, '.alicdn.com') == true)
			iframe(server('jk13') . $videourl);
		elseif (strstr($videourl, '27pan') == true)
			iframe(server('jk14') . $videourl);
		elseif (strstr($videourl, '.m3u8') == true)
			player($videourl);
		elseif (strstr($videourl, '.mp4') == true)
			player($videourl);
		elseif (strstr($videourl, '.flv') == true)
			player($videourl);
		elseif (strstr($videourl, '/share/') == true)
			iframe($videourl);
		elseif (strstr($videourl, '/v/') == true)
			iframe($videourl);
		elseif (strstr(setting('parse'), $_SERVER['HTTP_HOST']) == true)
			iframe($videourl);
		else
			iframe(setting('parse') . $videourl);
	} else
		echo '<div class="loading">请填写视频地址</div>';
} else {
	if ($videourl) {
		$vodserver =
		require ('../../../../application/extra/vodserver.php');
		for ($i = 1; $i <= count($vodserver); $i++)
			if (strstr($jiekouid, sprintf('%02s', $i)) == true)
				iframe(server('jk' . sprintf('%02s', $i)) . $videourl);
		if ($jiekouid > count($vodserver))
			iframe(server('jk01') . $videourl);
	} else
		echo '<div class="loading">请填写视频地址</div>';
}
loadfoot($videourl);

function loadhead($title) {
	echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . $title . '</title><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />';
	echo '<style type="text/css">html, body, iframe { display: block; margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #000; } .loading { font-family: Helvetica, Arial, Microsoft Yahei, sans-serif; background: #000; width: 90%; position: absolute; top: 50%; left: 50%; color:#fff; font-size: 16px; text-align: center; transform: translate(-50%, -50%); z-index:999;}</style></head><body>';
	if (setting('prestrain'))
		echo '<style type="text/css">@media (max-width: 768px) {.loading { top: 35%;}}</style>';
}

function loadfoot($videourl) {
	if (setting('autofull') == 1) {
		if (setting('prestrain'))
			echo '<script src="' . setting('prestrain') . '"></script>';
		if ($videourl)
			loadtips();
	} else
		echo '<script>delayed();</script>';
	echo '<div style="display:none">' . "\t\n" . setting('site_tj') . '</div>';
	echo '</body></html>';
}
?>