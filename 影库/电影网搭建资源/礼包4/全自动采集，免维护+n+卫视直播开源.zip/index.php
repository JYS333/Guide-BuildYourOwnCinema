<?php
/**
 * Created by www.yunpana.cn.
 * User: YuSheng
 * Date: 2018/7/11
 * Time: 8:32
 *   */
require dirname(__FILE__) . '/config/config.php';
require dirname(__FILE__) . '/system/app.php';
require dirname(__FILE__) . "/template/" . $template . "/index.php";
?>