<?php
/**
 * Created by www.yunpana.cn.
 * User: YuSheng
 * Date: 2018/7/11
 * Time: 13:37
 *   */
require $_SERVER['DOCUMENT_ROOT'] . '/config/config.php';
require $_SERVER['DOCUMENT_ROOT'] . '/system/app.php';
require $_SERVER['DOCUMENT_ROOT'] . "/template/" . $template . "/password.php";
?>