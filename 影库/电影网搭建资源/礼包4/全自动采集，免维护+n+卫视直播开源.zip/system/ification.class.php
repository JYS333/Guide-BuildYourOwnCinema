<?php

/**

 * Created by www.yunpana.cn.

 * User: YuSheng

 * Date: 2018/7/02

 * Time: 09:30

 *   */

class Classification{

public function switch($classification){

switch ($classification) {

case '电影':

return '1';

break;

case '连续剧':

return '2';

break;

case '综艺':

return '3';

break;

case '动漫':

return '4';

break;

case '动作片':

return '5';

break;

case '喜剧片':

return '6';

break;

case '爱情片':

return '7';

break;

case '科幻片':

return '8';

break;

case '恐怖片':

return '9';

break;

case '剧情片':

return '10';

break;

case '战争片':

return '11';

break;

case '国产剧':

return '12';

break;

case '港台剧':

return '13';

break;

case '日韩剧':

return '14';

break;

case '欧美剧':

return '15';

break;

case '微电影':

return '16';

break;

case '纪录片':

return '17';

break;

case '冒险片':

return '18';

break;

case '悬疑片':

return '19';

break; 

case '犯罪片':

return '20';

break;

case '灾难片':

return '21';

break;

case '魔幻片':

return '22';

break;

case '青春片':

return '23';

break;

case '音乐片':

return '24';

break;

case '其他片':

return '25';

break;

case '惊悚片':

return '26';

break;

case '动画片':

return '27';

break;

case '奇幻片':

return '28';

break;

case '其他剧':

return '29';

break;

case '国产动漫':

return '30';

break;

case '日本动漫':

return '31';

break;

case '欧美动漫':

return '32';

break;

case '其他动漫':

return '33';

break;

default:

# code...

break;

}

}

}

?>