<?php
/**
 * Created by www.yunpana.cn.
 * User: YuSheng
 * Date: 2018/6/28
 * Time: 14:59
 *   */
class ClassificationTwo{
public function switch($id){
switch ($id) {
case '1':
return '电影 - ';
break;
case '2':
return '连续剧 - ';
break;
case '3':
return '综艺 - ';
break;
case '4':
return '动漫 - ';
break;
case '5':
return '动作片 - ';
break;
case '6':
return '喜剧片 - ';
break;
case '7':
return '爱情片 - ';
break;
case '8':
return '科幻片 - ';
break;
case '9':
return '恐怖片 - ';
break;
case '10':
return '剧情片 - ';
break;
case '11':
return '战争片 - ';
break;
case '12':
return '国产剧 - ';
break;
case '13':
return '港台剧 - ';
break;
case '14':
return '日韩剧 - ';
break;
case '15':
return '欧美剧 - ';
break;
case '16':
return '微电影 - ';
break;
case '17':
return '纪录片 - ';
break;case '18':return '冒险片 - ';break;case '19':return '悬疑片 - ';break;case '20':return '犯罪片 - ';break;case '21':return '灾难片 - ';break;case '22':return '魔幻片 - ';break;case '23':return '青春片 - ';break;case '24':return '音乐片 - ';break;case '25':return '其他片 - ';break;case '26':return '惊悚片 - ';break;case '27':return '动画片 - ';break;case '28':return '奇幻片 - ';break;case '29':return '其他剧 - ';break;case '30':return '国产动漫 - ';break;case '31':return '日本动漫 - ';break;case '32':return '欧美动漫 - ';break;case '33':return '其他动漫 - ';break;
default:
# code...
break;
}
}
}
?>