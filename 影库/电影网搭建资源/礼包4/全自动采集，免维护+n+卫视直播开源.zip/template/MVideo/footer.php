<?php
/**
 * Created by www.yunpana.cn.
 * User: YuSheng
 * Date: 2018/6/30
 * Time: 9:40
 *   */

?>
<div class="container">
    <div id="footer">
        <p class="text-center">© 2018 Lstv All Rights Reserved.
        </p>
        <p class="text-center">本站提供的影视资源均系收集于各大视频网站,只提供web页面服务,并不提供影片资源存储,也不参与录制、上传<br>
若本站收录的节目无意侵犯了贵司版权，请通过底部邮箱来信告知，我们将及时更正和删除！</p>
<p class="text-center"><a href="http://www.1yu.cc/" target="_blank">赞助商链接</a>&nbsp;&nbsp;<a href="https://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=iqy@tom.com" target="_blank">E-mail：iqy@tom.com</a>
</p>

    </div>
</div>
<style type="text/css">
	body{cursor:url(/00S.TW-1.cur),default;}
	a:hover,li:hover,img:hover{cursor:url(/00S.TW-2.cur),pointer;}
</style>
<div style="display:none">

</div>